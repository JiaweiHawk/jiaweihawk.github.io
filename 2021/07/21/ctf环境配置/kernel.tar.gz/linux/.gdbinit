# .gdbinit
target remote localhost:1234

# 设置kernel基址
set $kernel_base=0xffffffff81000000
set $driver_base=0xffffffffc0000000

add-symbol-file kernel/vmlinux $kernel_base
add-symbol-file driver/vuln.ko $driver_base
