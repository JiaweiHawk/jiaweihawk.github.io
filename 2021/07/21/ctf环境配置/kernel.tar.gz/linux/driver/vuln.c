#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <linux/ioctl.h>
#include <linux/random.h>

#define VULN_WRITE		0x1737
#define VULN_READ		0x1738
#define VULN_ALLOC		0x1739
#define VULN_FREE		0x173A

void *buf;
static int vuln_open(struct inode *inode, struct file *filp);
static long vuln_unlocked_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);


static struct file_operations vuln_fops = {
	open : vuln_open,
	unlocked_ioctl : vuln_unlocked_ioctl,
};


static struct miscdevice vuln_miscdev = {
    .minor      = 11,
    .name       = "vuln",
    .fops       = &vuln_fops,
    .mode	    = 0666,
};

static int vuln_open(struct inode *inode, struct file *filp){
	return 0;
}

typedef struct {
	long long *addr;
	long long val;
} Data;

static long vuln_unlocked_ioctl(struct file *filp, unsigned int cmd, unsigned long arg){

	Data data;
	memset(&data, 0, sizeof(data));

    switch (cmd){

		case VULN_WRITE:

			if(copy_from_user(&data, (Data *)arg, sizeof(data)) != 0)
				return -ENOMEM;

			*(data.addr) = data.val;
			break;
		
		case VULN_READ:

			if(copy_from_user(&data, (Data *)arg, sizeof(data)) != 0)
				return -ENOMEM;

			if(copy_to_user((void*)data.val, data.addr, sizeof(data.val)) != 0)
				return -ENOMEM;
			break;
		
		case VULN_ALLOC:

			if(copy_from_user(&data, (Data *)arg, sizeof(data)) != 0)
				return -ENOMEM;
			
			if((buf = kmalloc(data.val, GFP_KERNEL)) == 0)
				return -ENOMEM;

			data.addr = buf;
			if(copy_to_user((Data *)arg, &data, sizeof(data)) != 0)
				return -ENOMEM;
			break;
		
		case VULN_FREE:

			kfree(buf);
			break;

		default:
			return -ENOTTY;
	}	

    return 0;
}


static int vuln_init(void){
	return misc_register(&vuln_miscdev);
}

static void vuln_exit(void){
	 misc_deregister(&vuln_miscdev);
}

module_init(vuln_init);
module_exit(vuln_exit);
MODULE_LICENSE("GPL");
