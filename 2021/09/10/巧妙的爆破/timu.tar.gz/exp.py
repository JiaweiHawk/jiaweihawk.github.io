from pwn import *
context.log_level = 'debug'

_elf = './timu'
# r = process(_elf)
r = remote('0', '12104')
def cal():
    for i in range(10000):
        if (0xcafebabe ^ u32(str(i).rjust(4, '0')))%10000 == i:
            print i
            return 0xcafebabe ^ u32(str(i))

ans = cal()
r.sendline(str(ans).rjust(12, '0'))
r.recv()
