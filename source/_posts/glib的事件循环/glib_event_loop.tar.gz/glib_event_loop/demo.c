#include <glib.h>
#include <stdio.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

static inline void debug(const char *format, ...) {
    va_list args;
    time_t current;
    struct tm *local;
    char buf[100];

    // 初始化变参
    va_start(args, format);

    // 获取当前时间
    time(&current);

    // 转换为本地时间
    local = localtime(&current);

    // 转换为字符串
    strftime(buf, sizeof(buf), "%H:%M:%S", local);

    // 打印
    printf("[%s] ", buf);
    vprintf(format, args);
    putchar('\n');
    fflush(stdout);

    // 结束可变参列表
    va_end(args);
}

typedef struct GSourceInput {
    GSource source;
    GPollFD *fd;
} GSourceInput;

/* 对于文件描述符的资源，prepare通常返回FALSE，
 * 因为其必须等poll结束后才能知道是否需要处理事件
 * 这里设置poll调用阻塞的超时时间为1000 ms
 */
gboolean g_source_input_prepare(GSource *source, gint *timeout)
{
    *timeout = 1000;
    debug("g_source_input_prepare() = FALSE");
    return FALSE;
}

gboolean g_source_input_check(GSource *source)
{
    GSourceInput *g_source_input = (GSourceInput*)source;

    if (g_source_input->fd->revents & G_IO_IN) {
        debug("g_source_input_check() = TRUE");
        return TRUE;
    }

    debug("g_source_input_check() = FALSE");
    return FALSE;
}

gboolean g_source_input_dispatch(GSource *source,
            GSourceFunc callback, gpointer user_data)
{
    char ch;
    GSourceInput *g_source_input = (GSourceInput*)source;

    read(g_source_input->fd->fd, &ch, 1);
    debug("g_source_input_dispatch() = %c", ch);

    // 停止事件循环
    if (ch == 'x') {
        g_main_loop_quit((GMainLoop*)user_data);
        return G_SOURCE_REMOVE;
    }

    return G_SOURCE_CONTINUE;
}

void g_source_input_finalize(GSource *source)
{
    GSourceInput *g_source_input = (GSourceInput*)source;
    g_source_remove_unix_fd(source, g_source_input->fd);
}

GSourceFuncs g_source_input_funcs = {
    .prepare = g_source_input_prepare,
    .check = g_source_input_check,
    .dispatch = g_source_input_dispatch,
    .finalize = g_source_input_finalize,
};

int main(void) {

    GMainLoop *g_main_loop;
    GMainContext *g_main_context;
    GSourceInput *g_source_input;
    struct termios term;

    g_source_input = (GSourceInput *)g_source_new(&g_source_input_funcs,
                        sizeof(GSourceInput));
    g_source_input->fd = g_source_add_unix_fd((GSource*)g_source_input,
                            STDIN_FILENO, G_IO_IN);

    // 关闭终端的行缓冲
    tcgetattr(g_source_input->fd->fd, &term);
    term.c_lflag &= ~(ICANON);
    tcsetattr(g_source_input->fd->fd, TCSANOW, &term);

    g_main_context = g_main_context_new();
    g_main_loop = g_main_loop_new(g_main_context, FALSE);

    g_source_set_callback((GSource *)g_source_input,
                        NULL, g_main_loop, NULL);

    g_source_attach((GSource*)g_source_input, g_main_context);
    g_source_unref((GSource*)g_source_input);

    g_main_loop_run(g_main_loop);

    g_main_context_unref(g_main_context);
    g_main_loop_unref(g_main_loop);

    return 0;
}
