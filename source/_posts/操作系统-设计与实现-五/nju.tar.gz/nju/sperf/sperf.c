#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/types.h>
#include <string.h>


// strace显示系统调用时间的参数
char STRACE_EXECUTE[] = "/strace", *STRACE_SHOW_TIME = "-T", *STRACE_OUTPUT = "-o", PATH_SPLIT = ':';

// glibc中定义好的环境变量
extern char **environ;
//管道文件描述符，用来进程间通信
int pipefd[2] = {0};


/*
 * 实际上glibc已经提前解析好环境变量，不需要过多在进行解析
 * 对于参数，只需要添加-T,显示具体的系统调用的时间即可
 */
char **parse_args_environ(int argc, char *argv[]) {
	char **exec_arg = (char**)malloc(sizeof(char*) * (argc + 4));
	assert(exec_arg && argv);


	//exec_arg[0] = STRACE_PATH, exec_arg[1] = STRACE_SHOW_TIME, exec_arg[2] = "-o", exec_arg[3] = /proc/`pid`/fd, exec_arg[4:] = argv[1:]
	//首先直接复制原始的argv即可，之后会用strace的路径替换exec_arg[0],因此没有必要进行复制
	exec_arg[1] = STRACE_SHOW_TIME;
	exec_arg[2] = STRACE_OUTPUT;
	for(int i = 1; i <= argc; ++i) { exec_arg[i + 3] = argv[i]; }

	return exec_arg;
}


/*
 * 子进程部分
 * 其用来执行/path/to/strace -T -o /proc/`pid`/fd command arg
 */
void child(int argc, char *argv[]) {

	char fd_path[20] = {0}, strace_path[4097] = {0}; // Linux中路径长度最大不超过4096字符


	// 首先关闭读管道文件描述符
	close(pipefd[0]);

	// 获取部分参数
	char **exec_arg = parse_args_environ(argc, argv);

	// 获取exec_arg[3], 即当前进程的写管道描述符
	exec_arg[3] = fd_path;
	sprintf(fd_path, "/proc/%d/%d", getpid(), pipefd[1]);


	//开始根据环境变量中的PATH值进行切割和测试，从而获取strace的路径信息和exec_arg[0]
	exec_arg[0] = strace_path;
	int pathBegin = 0, i = 0;
	char *path = getenv("PATH");

	while(path[i]) {
		while(path[i] && path[i] != PATH_SPLIT) { ++i; }

		// 此时path[pathBegin: i - 1]就是待检测的路径
		strncpy(strace_path, path + pathBegin, i - pathBegin);
		strncpy(strace_path + i - pathBegin, STRACE_EXECUTE, sizeof(STRACE_EXECUTE) +1);

		execve(strace_path, exec_arg, environ);	//如果正确执行，则不会返回，并且将strace输出到写管道描述符
	}


	// 如果执行了execve，则理论上不会执行到这里——也就是如果执行到了这里，必然是execve没有正确执行
	perror("execve");
	exit(EXIT_FAILURE);
}



/*
 * 父进程部分
 * 其解析子进程的管道输出，并且以GUI的形式展示输出
 */
void parent(void) {
	printf("parent\n");
}


int main(int argc, char *argv[]) {

	//提前创建管道文件描述符，用来之后进程间通信
	if(pipe(pipefd) == -1) {
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	

	//创建新进程，其中子进程用来执行/path/to/strace -T -o /proc/`pid`/fd
	int pid = 0;
	if((pid = fork()) == -1) {
		perror("fork");
		exit(EXIT_FAILURE);
	}else if(pid > 0) { parent(); }
	else { child(argc, argv); }
}
