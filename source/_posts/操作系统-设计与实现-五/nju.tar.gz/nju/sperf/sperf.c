#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <fcntl.h>

#define TIME_INTERVAL_SECONDS (1)
#define MAX_STRACE_OUTPUT_SIZE (4095)




// strace显示系统调用时间的参数
char STRACE_EXECUTE[] = "/strace", *STRACE_SHOW_TIME = "-T", *STRACE_OUTPUT = "-o", PATH_SPLIT = ':';

// glibc中定义好的环境变量
extern char **environ;
//管道文件描述符，用来进程间通信
int pipefd[2] = {0};


/*
 * 实际上glibc已经提前解析好环境变量，不需要过多在进行解析
 * 对于参数，只需要添加-T,显示具体的系统调用的时间即可
 */
char **parse_args_environ(int argc, char *argv[]) {
	char **exec_arg = (char**)malloc(sizeof(char*) * (argc + 4));
	assert(exec_arg && argv);


	//exec_arg[0] = STRACE_PATH, exec_arg[1] = STRACE_SHOW_TIME, exec_arg[2] = "-o", exec_arg[3] = /proc/`pid`/fd, exec_arg[4:] = argv[1:]
	//首先直接复制原始的argv即可，之后会用strace的路径替换exec_arg[0],因此没有必要进行复制
	exec_arg[1] = STRACE_SHOW_TIME;
	exec_arg[2] = STRACE_OUTPUT;
	for(int i = 1; i <= argc; ++i) { exec_arg[i + 3] = argv[i]; }

	return exec_arg;
}


/*
 * 子进程部分
 * 其用来执行/path/to/strace -T -o /proc/`pid`/fd command arg
 */
void child(int argc, char *argv[]) {

	char fd_path[20] = {0}, strace_path[MAX_STRACE_OUTPUT_SIZE] = {0}; // Linux中路径长度最大不超过MAX_STRACE_OUTPUT_SIZE字符

	// 首先关闭读管道文件描述符
	close(pipefd[0]);


	// 获取部分参数
	char **exec_arg = parse_args_environ(argc, argv);


	// 获取exec_arg[3], 即当前进程的写管道描述符
	exec_arg[3] = fd_path;
	sprintf(fd_path, "/proc/%d/fd/%d", getpid(), pipefd[1]);


	//开始根据环境变量中的PATH值进行切割和测试，从而获取strace的路径信息和exec_arg[0]
	exec_arg[0] = strace_path;
	int pathBegin = 0, i = 0;
	char *path = getenv("PATH");

	while(path[i]) {
		while(path[i] && path[i] != PATH_SPLIT) { ++i; }

		// 此时path[pathBegin: i - 1]就是待检测的路径
		strncpy(strace_path, path + pathBegin, i - pathBegin);
		strncpy(strace_path + i - pathBegin, STRACE_EXECUTE, sizeof(STRACE_EXECUTE) +1);

		execve(strace_path, exec_arg, environ);	//如果正确执行，则不会返回，并且将strace输出到写管道描述符

		pathBegin = ++i;
	}


	// 如果执行了execve，则理论上不会执行到这里——也就是如果执行到了这里，必然是execve没有正确执行
	fprintf(stderr, "%s\n", "execve() could not find strace");
	fflush(stderr);
	exit(EXIT_FAILURE);
}




/*
 * 用来统计系统调用的信息
 */
#define SYSCALL_SIZE	(400)
typedef struct SYSCALL_INFO {
	char *syscall;
	double time;
} Syscall_Info;
Syscall_Info *syscall_info_sort_by_name[SYSCALL_SIZE] = {NULL}, **syscall_info_sort_by_time[SYSCALL_SIZE] = {NULL};
long long syscall_info_number = 0;
double syscall_time_total = 0;



/*
 * 根据系统调用字符串，查找syscall_info_sort_by_name数组，从而获取字符串数组所在的下标
 */
int syscall_info_find_idx_by_name(const char *name) {
	int left = 0, right = syscall_info_number - 1;
	while(left <= right) {
		int middle = left + (right - left) / 2, cmp = strcmp(syscall_info_sort_by_name[middle]->syscall, name);
		if(cmp == 0) { return middle; }
		else if(cmp < 0) { left = middle + 1; }
		else { right = middle - 1; }
	}
	return -1;
}


/*
 * 根据系统调用，排序名称或者消耗时间
 * 快排
 */
#define syscall_info_sort_by_name_sort() _syscall_info_qsort(syscall_info_sort_by_name, 0, syscall_info_number - 1, syscall_info_sort_by_name_cmp)
#define syscall_info_sort_by_time_sort() _syscall_info_qsort(syscall_info_sort_by_time, 0, syscall_info_number - 1, syscall_info_sort_by_time_cmp)
void _syscall_info_qsort(Syscall_Info **base, int left, int right, int (*cmp)(Syscall_Info **base, int i, int j)) {
	if(left >= right) { return; }
	int leftIndex = left, rightIndex = right + 1;
	Syscall_Info *temp = NULL;

	while(1) {
		while((*cmp)(base, left, ++leftIndex) >= 0) {
			if(leftIndex == right) { break; }
		}

		while((*cmp)(base, left, --rightIndex) <= 0) {;}

		if(leftIndex >= rightIndex) { break; }

		temp = base[leftIndex];
		base[leftIndex] = base[rightIndex];
		base[rightIndex] = temp;
	}


	temp = base[left];
	base[left] = base[rightIndex];
	base[rightIndex] = temp;

	_syscall_info_sort(base, left, rightIndex - 1, cmp);
	_syscall_info_sort(base, rightIndex +1, right, cmp);
}


int syscall_info_sort_by_name_cmp(Syscall_Info **base, int i, int j) {
	return strcmp(base[i]->syscall, base[j]->syscall);
}

#define epsilon (1e-6)  
int syscall_info_sort_by_time_cmp(Syscall_Info **base, int i, int j) {
	if(base[i]->time - base[j]->time < epsilon) { return -1; }
	return 1;
}




/*
 * 添加系统调用的相关信息，
 * 如果系统调用存在的话，直接增加其时间即可
 * 如果系统调用不存在的话，新创建
 * 插入完成后，完成相关的排序即可
 */
void syscall_info_insert_and_sort(const char *name, double time) {

	syscall_time_total += time;

	int syscall_info_idx = 0;
	if((syscall_info_idx = syscall_info_find_idx_by_name(name)) == -1) {
		//此时系统调用信息不能存在，需要创建一个
		Syscall_Info *syscall_info = (Syscall_Info*)malloc(sizeof(Syscall_Info));
		syscall_info->syscall = name;
		syscall_info->time = time;

		syscall_info_sort_by_name[syscall_info_number] = syscall_info;
		syscall_info_sort_by_time[syscall_info_number++] = syscall_info;


		syscall_info_sort_by_name_sort();
		syscall_info_sort_by_time_sort();
	}else {
		//此时系统调用信息存在，直接修改并排序即可
		syscall_info_sort_by_name[syscall_info_idx]->time += time;
		syscall_info_sort_by_time_sort();
	}
}



/*
 * 父进程部分
 * 其解析子进程的管道输出，并且以GUI的形式展示输出
 */
void parent(void) {
	char buf[MAX_STRACE_OUTPUT_SIZE + 1] = {0};
	int read_result = 0, buf_available = 0;


	//关闭无用的写管道文件描述符
	close(pipefd[1]);


	//设置读管道文件描述符为非阻塞模式
	if(fcntl(pipefd[0], F_SETFD, fcntl(pipefd[0], F_GETFD) | O_NONBLOCK) == -1) {
		perror("fcntl");
		exit(EXIT_FAILURE);
	}


	while(1) {

		//可能子进程确实没有输出，或子进程终止，需要辨别这两种情况
		switch(read_result = read(pipefd[0], buf + buf_available, MAX_STRACE_OUTPUT_SIZE - buf_available)) {
			//子进程当前没有输出，但未终止
			case -1:
				break;
			//子进程当前终止
			case 0:
				exit(EXIT_SUCCESS);
				break;
			//此时子进程和父进程正常通过管道进行通信
			default:
				buf[buf_available + read_result] = 0;
				buf_available = parse_strace_output(buf);
		}


		// 节省资源，休眠TIME_INTERVAL_SECONDS秒
		sleep(TIME_INTERVAL_SECONDS);
	}
}


int main(int argc, char *argv[]) {

	//提前创建管道文件描述符，用来之后进程间通信
	if(pipe(pipefd) == -1) {
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	

	//创建新进程，其中子进程用来执行/path/to/strace -T -o /proc/`pid`/fd
	switch(fork()) {
		case -1:
			perror("fork");
			exit(EXIT_FAILURE);
			break;
		case 0:
			child(argc, argv);
			break;
		default:
			parent();

	}

	/*
	 * 理论上，child由于执行execve，则其不会返回，即不可能执行到这里
	 * parent由于在read系统调用异常时，会直接返回，也不可能执行到这里
	 */
	fprintf(stderr, "%s\n", "sperf wrong return");
	fflush(stderr);
	exit(EXIT_FAILURE);
}
