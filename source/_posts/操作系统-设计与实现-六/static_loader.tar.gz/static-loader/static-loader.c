#include <stdio.h>
#include <stdlib.h>
#include <elf.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <string.h>

#define KB * (1024ll)
#define MB * (1024ll KB)
/*
 * 传入的环境变量数组
 */
extern char **environ;
/*
 * 载入64位的静态链接程序exec，其参数个数为argc，其参数指针数组为argv，环境变量数组为environ
 */
void static_load_elf(char *exec, int exec_argc, char *exec_argv[], char **exec_environ); /* 载入64位的静态链接程序exec的各个segment */
void static_load_segments(int exec_fd, Elf64_Ehdr *elf64_ehdr);
/*
 * 根据System V api文档
 * 初始化程序的堆栈结构，即设置argc，argv和envp即可
 */
void *static_init_stack(int exec_argc, char *exec_argv[], char **exec_environ);
/*
 * 根据System V api文档
 * 初始化相关的寄存器，自然包括控制流的跳转
 */
void static_init_registers(Elf64_Ehdr *elf64_ehdr, void *stack);





/*
 * 载入64位的静态链接程序exec，其参数个数为argc，其参数指针数组为argv，环境变量数组为environ
 */
void static_load_elf(char *exec, int exec_argc, char *exec_argv[], char **exec_environ) {
	//以只读模式打开exec文件
	int exec_fd = open(exec, O_RDONLY);

	if(exec_fd < 0) { exit(EXIT_FAILURE); }

	/*
	 * 由于这里只展示原理性的东西
	 * 因此不会进行特别多的检查
	 */


	//载入静态链接的起始部分(头部、Program Header)，默认4KB以内
	Elf64_Ehdr *elf64_ehdr = (Elf64_Ehdr*)mmap(
			NULL,		//addr，即映射的虚拟地址
			4 KB, 		//length，映射的字节长度
			PROT_READ,	//prot，映射内存的属性
			MAP_SHARED,	//flags，映射内存的标志
			exec_fd,	//fd，映射内存的文件描述符
			0		//offset，文件描述符的起始偏移
	);
	if(elf64_ehdr == MAP_FAILED) { exit(EXIT_FAILURE); }

#ifdef DEBUG
	printf("elf64_ehdr address => %p\n", elf64_ehdr);
	printf("elf64_ehdr->e_phentsize => %d\n", elf64_ehdr->e_phentsize);
	printf("elf64_ehdr->e_phnum => %d\n", elf64_ehdr->e_phnum);
	printf("elf64_ehdr->e_phoff => %ld\n", elf64_ehdr->e_phoff);
#endif



	// 载入64位的静态链接程序exec的各个segment即可
	static_load_segments(exec_fd, elf64_ehdr);


	// 初始化堆栈结构，即设置argc，argv和envp即可
	void *stack = static_init_stack(exec_argc, exec_argv, exec_environ);


	// 完成寄存器初始化并进行跳转
	static_init_registers(elf64_ehdr, stack);
}




/*
 * 载入64位的静态链接程序exec的各个segment
 */
void static_load_segments(int exec_fd, Elf64_Ehdr *elf64_ehdr) {

	//首先读取segments描述符数组，即Program header数组
	Elf64_Phdr *elf64_phdrs = (Elf64_Phdr*)(((uintptr_t)(elf64_ehdr)) + elf64_ehdr->e_phoff);
#ifdef DEBUG
	printf("elf64_phdrs address => %p\n", elf64_phdrs);
	printf("prot: PROT_READ => %#x PROT_WRITE => %#x PROT_EXEC => %#x\n", PROT_READ, PROT_WRITE, PROT_EXEC);
	printf("Elf64_Phdr->p_flags: PF_R => %#x PF_W => %#x PF_X => %#x\n", PF_R, PF_W, PF_X);
#endif


	//依次遍历segments，将其载入内存
	for(int i = 0; i < elf64_ehdr->e_phnum; ++i) {
		Elf64_Phdr *elf64_phdr = &elf64_phdrs[i];
		//如果对应的p_type字段是PT_LOAD，则直接将其载入至内存中即可
		if(elf64_phdr->p_type == PT_LOAD) {
			uint64_t prot = 0;

			//根据elf64_phdr->p_flags来判断映射权限
			if(elf64_phdr->p_flags & PF_R) { prot |= PROT_READ; }
			if(elf64_phdr->p_flags & PF_W) { prot |= PROT_WRITE; }
			if(elf64_phdr->p_flags & PF_X) { prot |= PROT_EXEC; }


			/*
			 * segments的大小和虚拟地址根据p_align字段进行对齐即可
			 */
			void *elf64_phdr_vaddr_align = (void*)((uintptr_t)elf64_phdr->p_vaddr & (~((uintptr_t)elf64_phdr->p_align - 1)));
			size_t elf64_phdr_length_align = elf64_phdr->p_memsz + ((uintptr_t)elf64_phdr->p_vaddr - (uintptr_t)elf64_phdr_vaddr_align);
			off_t elf64_phdr_offset_align = elf64_phdr->p_offset & (~((uintptr_t)elf64_phdr->p_align - 1));

#ifdef DEBUG
			printf("elf64_phdrs[%d] elf64_phdr_vaddr_align => %p, elf64_phdr_length_align => %#lx, elf64_phdr_offset_align => %#lx prots => %#lx\n", i, elf64_phdr_vaddr_align, elf64_phdr_length_align, elf64_phdr_offset_align, prot);
#endif
			void *address = mmap(
					elf64_phdr_vaddr_align,		//addr，即映射的虚拟地址
					elf64_phdr_length_align, 	//length，映射的字节长度
					prot,				//prot，映射内存的属性
					MAP_PRIVATE | MAP_FIXED,	//flags，映射内存的标志
					exec_fd,			//fd，映射内存的文件描述符
					elf64_phdr_offset_align		//offset，文件描述符的起始偏移
			);

			//由于可能存在bss段等，因此需要将多余的空间置为0，否则执行会错误
			memset(((char*)elf64_phdr->p_vaddr) + elf64_phdr->p_filesz, 0, elf64_phdr->p_memsz - elf64_phdr->p_filesz);

			//测试，用来输出载入的segment的相关地址信息
#ifdef DEBUG
			printf("elf64_phdrs[%d] address => %p p_vaddr => %#lx; p_memsz => %#lx; p_flags => %#x p_filesz => %#lx p_align => %#lx\n\n", i, address, elf64_phdr->p_vaddr, elf64_phdr->p_memsz, elf64_phdr->p_flags, elf64_phdr->p_filesz, elf64_phdr->p_align);
#endif
		}
	}
}


/*
 * 根据System V api文档
 * 初始化程序的堆栈结构，即设置argc，argv和envp即可
 */
void *static_init_stack(int exec_argc, char *exec_argv[], char **exec_environ) {
	/*
	 * 申请堆栈所需要的地址
	 */
	void *stack = mmap(
			NULL,				//addr，即映射的虚拟地址
			1 MB, 				//length，映射的字节长度
			PROT_READ | PROT_WRITE,		//prot，映射内存的属性
			MAP_PRIVATE | MAP_ANONYMOUS,	//flags，映射内存的标志
			-1,				//fd，映射内存的文件描述符
			0				//offset，文件描述符的起始偏移
	);


	//这里栈空间的起始位置
	uintptr_t *sp = (uintptr_t*)((uintptr_t)(stack) + 1 MB - 4 KB);

	//这里设置当前栈帧的顶部
	void *res = (void*)sp;


	//压入exec_argc
	*sp++ = exec_argc;

	//压入exec_argv
	for(int i = 0; exec_argv[i]; ++i) {*sp++ = (uintptr_t)exec_argv[i];}
	//压入exec_argv结束的0
	*sp++ = 0;

	//压入exec_environ
	int environ_idx = 0;
	for(; exec_environ[environ_idx]; ++environ_idx) {
		if(strchr(exec_environ[environ_idx], '_') != exec_environ[environ_idx]) { *sp++ = (uintptr_t)exec_environ[environ_idx]; }
		else {
			char *environ = (char*)malloc(strlen(exec_argv[0] + 3));
			sprintf(environ, "_=%s", exec_argv[0]);
			*sp++ = (uintptr_t)environ;
		}
	}
	//压入exec_environ结束的0
	*sp++ = 0;


	//压入auxiliary vector entries，这些是内核提供给用户空间的一些设置参数，否则glibc无法正常运行。不能直接复制加载器的，否则待加载程序会崩溃
	//for(Elf64_auxv_t *elf64_auxv_t = (Elf64_auxv_t*)&exec_environ[environ_idx + 1]; elf64_auxv_t->a_type != AT_NULL; ++elf64_auxv_t) {
	//	*((Elf64_auxv_t*)sp) = *elf64_auxv_t;
	//	sp = (uintptr_t*)((Elf64_auxv_t*)sp + 1);
	//}
	*((Elf64_auxv_t*)sp) = (Elf64_auxv_t){ .a_type = AT_RANDOM, .a_un.a_val = (uintptr_t)(stack) + 1 MB - 16};
	sp = (uintptr_t*)((Elf64_auxv_t*)sp + 1);
	*((Elf64_auxv_t*)sp) = (Elf64_auxv_t){ .a_type = AT_NULL};
	


#ifdef DEBUG
	printf("stack => %p\n", res);
	int argc = *(int*)res, i;
	printf("argc => %d\n", argc);

	char **argv = ((char**)res) + 1;
	for(i = 0; i < argc; ++i) { printf("argv[%d] = %s\n", i, argv[i]); }

	char **environ = argv + argc + 1;
	for(i = 0; environ[i]; ++i) { printf("environ[%d] = %s\n", i, environ[i]); }

	Elf64_auxv_t *elf64_auxv_t = (Elf64_auxv_t*)(environ + i + 1);
	for(i = 0; elf64_auxv_t[i].a_type != AT_NULL; ++i) { printf("auxiliary[%d].a_type = %#lx, auxiliary[%d].a_un.a_val = %#lx\n", i, elf64_auxv_t[i].a_type, i, elf64_auxv_t[i].a_un.a_val); }

#endif

	return res;
}




/*
 * 根据System V api文档
 * 初始化相关的寄存器，自然包括控制流的跳转
 */
void static_init_registers(Elf64_Ehdr *elf64_ehdr, void *stack){

	//通过内联汇编，初始化寄存器，并完成跳转
	__asm__ volatile(
			"mov %0, %%rsp;"	//将rsp设置为之前初始化的栈的位置
			"xor %%rdx, %%rdx;"	//将rdx设置为atexit部分
			"jmp *%1"		//将待跳转的目标地址存到寄存器中，然后间接跳转
			:
			: "r"(stack), "r"(elf64_ehdr->e_entry)
			: "rdx");
}


int main(int argc, char *argv[]) {

	if(argc == 1) {
		printf("Usage: static-loader file [args...]\n");
		exit(EXIT_SUCCESS);
	}

	/*
	 * argv[0] = "./static-loader"
	 * argv[1] = 待载入程序路径
	 * argv[2 : argc] = 待载入程序参数
	 * argv[argc] = 0
	 */
	static_load_elf(argv[1], argc - 1, argv + 1, environ);


	//理论上，完成跳转后，程序通过hlt退出，永远不会执行到该处
	exit(EXIT_FAILURE);
}
