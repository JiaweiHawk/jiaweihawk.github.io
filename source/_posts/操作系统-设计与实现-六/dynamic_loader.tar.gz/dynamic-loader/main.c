#include "dynamic.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>


/*
 * 当前程序加载的动态链接库中所有的程序
 */
static Symbol *symbols[128] = {NULL};
static int symbols_size = 0;


/*
 * 处理动态链接库中导入符号类型的符号
 */
void
do_type_import_symol(Symbol *symbol)
{
	assert(symbol->type == SYMBOL_TYPE_IMPORT);
	if(symbol == NULL) { return; }

	printf("[*] try to resolve the import symbol:%s\n", symbol->name);

	// 遍历程序的符号表，如果找到符号特征(符号名称)相同的，则解析符号即可
	for(int i = 0; i < symbols_size; ++i) {
		if(!strcmp(symbol->name, symbols[i]->name)) {
			printf("[*] succeed to resolve the import symbol:%s\n", symbol->name);
			symbol->offset = (uint64_t)symbols[i]->offset;
			return;
		}
	}

	printf("[*] failed to resolve the import symbol:%s\n", symbol->name);
}



/*
 * 处理动态链接库中导出符号类型的符号
 */
void
do_type_export_symbol(Symbol *symbol, void *base_addr)
{
	assert(symbol->type == SYMBOL_TYPE_EXPORT);
	if(symbol == NULL) { return; }

	printf("[*] try to resolve the export symbol:%s\n", symbol->name);

	symbols[symbols_size] = symbol;
	symbols[symbols_size]->offset += (uint64_t)base_addr;
	++symbols_size;
	
	printf("[*] succeed to resolve the export symbol:%s\n", symbol->name);
}



/*
 * 这里根据库的名称
 * 加载当前目录下的.o文件即可
 */
void
load(const char *lib_name)
{
	if(lib_name == NULL) { return; }

	printf("[*] try to load the %s\n", lib_name);

	int lib_name_len = strlen(lib_name);
	char *lib_path = (char*)malloc(sizeof(char) * (lib_name_len + 2 + 7));
	assert(lib_path != NULL);
	sprintf(lib_path, "./%s.dynlib", lib_name);

#ifdef DEBUG
	printf("[*] try to load the %s with path:%s\n", lib_name, lib_path);
#endif

	int fd = -1;
	if((fd = open(lib_path, O_RDONLY)) < 0) {
		printf("[*] fail to open the %s\n", lib_name);
		free(lib_path);
		return;
	}

	//通过mmap映射
	void *base_addr = NULL;
	if((base_addr = mmap(NULL, 4096, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0)) == NULL) {
		printf("[*] fail to load the %s\n", lib_name);
		free(lib_path);
		return;
	}


	/*
	 * 由于每一个动态链接的符号表在其首部
	 * 则依次遍历即可
	 *
	 * 如果是导出表，则向全局符号表中添加符号即可
	 * 如果是导入表，则遍历全局符号表，查找对应的符号即可
	 */
	for(Symbol *symbol = (Symbol*)base_addr; symbol->type != SYMBOL_TYPE_TERMINATE; ++symbol) {
#ifdef DEBUG
		printf("[*] symbol address => %p\n", symbol);
		printf("[*] try to load the symbol: %s\n", symbol->name);
#endif
		switch(symbol->type) {
			case SYMBOL_TYPE_IMPORT:
				do_type_import_symol(symbol);
				break;
			case SYMBOL_TYPE_EXPORT:
				do_type_export_symbol(symbol, base_addr);
				break;
		}
	}

	printf("[*] succeed to load the %s\n", lib_name);
	free(lib_path);
}


/*
 * 调用动态链接库中的符号表
 * 即遍历程序所有的符号表，找出给定的符号特征并且执行即可
 */
void
do_execute_symbol(const char *name)
{
	if(name == NULL) { return; }

	printf("[*] try to execute the symbol:%s\n", name);

	// 遍历程序的符号表，如果找到符号特征(符号名称)相同的，则执行符号即可
	for(int i = 0; i < symbols_size; ++i) {
		if(!strcmp(name, symbols[i]->name)) {
#ifdef DEBUG
			printf("[*] the address of the symbol:%s is %lx\n", name, symbols[i]->offset);
#endif
			printf("[*] %s() = %ld\n", name, ((uint64_t (*)())symbols[i]->offset)());
			return;
		}
	}

	printf("[*] failed to execute the symbol:%s\n", name);
}

int main(void) {
	setbuf(stdin, NULL);
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);

	load("liba");
	do_execute_symbol("liba_func");
	load("libb");
	do_execute_symbol("libb_func");
	return 0;
}
