#ifndef __DYNAMIC_H_
#define __DYNAMIC_H_

#define SYMBOL_SIZE (64)

#define SYMBOL_TYPE_TERMINATE	(0)
#define SYMBOL_TYPE_IMPORT	(1)
#define SYMBOL_TYPE_EXPORT	(2)


#ifdef __ASSEMBLER__
/*
 * 这里主要定义一些汇编指令下的宏，方便编写汇编源代码
 */

//定义一个符号表的起始
#define DYNLIB_SYMS	symbols_start:

/*
 * 定义一个符号表的终结
 * .align ALIGN GAP;		按ALIGN对齐下一个符号，中间使用GAP填充
 * .fill REPEAT, SIZE, VALUE;	将SIZE大小的VALUE值拷贝REPEAT次
 */
#define DYNLIB_SYMS_END	.align SYMBOL_SIZE, 0; \
	.fill SYMBOL_SIZE, 1, 0; 

/*
 * 在汇编源代码中，定义导出表
 * 其中包含相对载入基址的相对偏移，以及符号特征
 * .quad VALUE			定义了一个QUAD类型的数据，其值为VALUE
 * .asciz VALUE			使用ASCII字符声明VALUE文本字符串，并在结尾自动添加结束符\0
 * #VAR				将宏参数转换为字符常量
 */
#define EXPORT(name) .align SYMBOL_SIZE, 0; \
	.quad (name - symbols_start); \
	.quad SYMBOL_TYPE_EXPORT; \
	.asciz #name;


/*
 * 在汇编源代码中，定义导入表
 * 其中包含符号待解析地址，以及符号特征
 * .quad VALUE			定义了一个QUAD类型的数据，其值为VALUE
 * .ascii VALUE			使用ASCII字符声明VALUE文本字符串，结尾没有结束符\0
 * str1##str2			将两个token连接为字符常量
 */
#define IMPORT(name) .align SYMBOL_SIZE, 0; \
	name##_dyn: \
	.quad 0; \
	.quad SYMBOL_TYPE_IMPORT; \
	.asciz #name; \

#else
/*
 * 前面汇编源代码中仅仅实现了相关动态链接库的符号标记
 * 这里是上述动态链接库的具体符号标记的含义
 */

#include <stdint.h>
typedef struct SYMBOL {
	uint64_t offset;
	uint64_t type;
	char name[SYMBOL_SIZE - sizeof(uint64_t) - sizeof(uint64_t)];
} Symbol;

#define SIZE(arr) (sizeof((arr)) / sizeof((arr)[0]))

#endif		//__ASSEMBLER__


#endif
