#ifndef __COMMON_H__
#define __COMMON_H__


    #include <kernel.h>
    #include <klib.h>
    #include <klib-macros.h>

    /*
     * 完善struct spinlock结构体的定义
     */
    struct spinlock {
      const char *name;
      int lock;
      bool saved_interrupt_status;
    };



    /*
     * 完善struct semaphore结构体的定义
     */
    struct semaphore {
        spinlock_t spinlock;
        int val;
    };



    /*
     * 列举了进程所有可能的状态
     * 其中IDLE就是mpe_init()中创建的进程，其状态始终不变，可以在多个CPU上进行操作
     */
    enum TASK_STATUS {
        RUNNING, READY, WAIT
    };

    /*
     * 完善struct task_t结构体的定义
     */
    #define STACK_SIZE (4096)
    struct task {
        struct task *fwd, *bck;
        Context *ctx;
        void* fence1;
        uint8_t stack[STACK_SIZE];
        void* fence2;
        const char *name;
        enum TASK_STATUS status;
    };



    /*
     * 当宏DEBUG被定义的时候
     * 输出相关的调试信息
     */
    #ifdef DEBUG
        #define debug(fmt, args...) printf("[*] cpu:%d func:%s:"fmt, cpu_current(),  __func__, args)
    #else
        #define debug(fmt, ...) ((void)0)
    #endif


#endif