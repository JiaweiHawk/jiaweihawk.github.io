#ifndef __PMM_H__
#define __PMM_H__

    #include <common.h>



    /*
     * 实现操作系统的锁结构，从而实现互斥
     * 这里并不是自旋锁(但可以通过简单包装，即不停循环即可)
     * 其仅仅可以上锁和开锁。如果上锁失败，则不会重新进行尝试
     */
    #define locked		(0)
    #define unlocked	(1)
    typedef int lock_t;



    #define BITPERCHAR 8

    /*
     * 设置Buddy算法的相关参数
     */
    #define B  * (1)
    #define KB * (1024)
    #define MB * (1024 KB)
    #define LOG_PAGE_SIZE (12)
    #define PAGE_SIZE (1 << LOG_PAGE_SIZE)
    #define MAX_SIZE  (16 MB)
    
    
    
    /*
     * 初始化Buddy结构
     * 一开始默认所有的内存对象都属于最大下所对应的内存对象
     * 初始化对应的映射结构、锁结构等
     */
    typedef struct MALLOC_CHUNK {
    	//当内存对象处于未使用、或被free时，通过 MALLOC_CHUNK来管理
    	struct MALLOC_CHUNK *fd;
    	struct MALLOC_CHUNK *bk;	//该字段仅在buddy的双向链表结构中使用，slab中不使用该字段
    } Malloc_Chunk;
    
    typedef struct BUDDY {
    	Malloc_Chunk *ptr_list;		//即指向buddy的双向链表的表头数组
    	unsigned char *ptr_page2idx;	//将虚拟地址对应的虚拟页根据其内存对象的大小，映射到所属的表头数组对应的下标中
    	uintptr_t startAddress;		//即虚拟地址在ptr_page2idx数组的下标为:(address - startAddress) >> LOG_PAGE_SIZE
    	lock_t lock_buddy;		//buddy结构体中的双向链表的表头数组的锁
    	int buddy_size;			//即双向链表的表头数组的个数
    } Buddy;
    
    /*
     * 定义初始化slab相关的数据结构
     * 即每个处理器需要在本地提前准备一些相关的slab
     */
    typedef struct SLAB_PER_CPU {
    	int slab_size;		//即当前存储的slab种数
    	lock_t *locks;		//为了尽可能的高效，每一种slab，分配一把锁
    	uintptr_t slabs;	//存储着当前cpu下所有的slab，可以简单理解为slab表头数组，可以简单理解为((Malloc_Chunk*)(((uintptr_t)(slabs)) + log_ceil(2, (size / sizeof(uintptr_t) / 8))))->fd存储的就是slab中具体的内存对象
    } Slab_Per_Cpu;

    
    //buddy相关的宏操作
    #define buddy_ptr_list_at(buddy, idx) (((Malloc_Chunk*)((buddy)->ptr_list)) + (idx))
    #define buddy_chunk_is_used (0x1)
    #define buddy_get_chunk_use_flag(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] >> (sizeof(unsigned char) * 8 - 1))
    #define buddy_set_chunk_used(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] |= (((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)))
    #define buddy_set_chunk_unused(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] &= ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)) - 1))
    #define buddy_get_idx(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] & ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)) - 1))
    #define buddy_set_idx(buddy, address, idx) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] = ((idx) | (((uint64_t)buddy_get_chunk_use_flag((buddy), (address))) << (sizeof(unsigned char) * 8 - 1))))




    #define slab_get_cpu(slab_cpus, i)	(((Slab_Per_Cpu*)(slab_cpus)) + (i))
    #define slab_cpu_get_lock(slab, idx)	(((Slab_Per_Cpu*)(slab))->locks + (idx))
    #define slab_cpu_get_slabs(slab, idx)	((Malloc_Chunk*)(((Slab_Per_Cpu*)(slab))->slabs + (idx) * sizeof(uintptr_t)))


    /*
     * 使用slab机制分配内存
     */
    #define slab_chunk_is_used (0x3)
    #define slab_get_chunk_use_flag(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] >> (sizeof(unsigned char) * 8 - 2))
    #define slab_set_chunk_used(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] |= (((uint64_t)1) << (sizeof(unsigned char) * 8 - 2)))
    #define slab_get_idx(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] & ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 2)) - 1))
    #define slab_set_idx(buddy, address, idx) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] = ((idx) | (((uint64_t)slab_get_chunk_use_flag((buddy), (address))) << (sizeof(unsigned char) * 8 - 2))))
#endif