#ifndef __KMT_H__
#define __KMT_H__

  #include <common.h>

  /*
   * 完善自旋锁的结构体定义
   */
  #define SPINLOCK_UNLOCKED (0)
  #define SPINLOCK_LOCKED (1)


  #define IRQ_SAVE_CONTEXT_SEQ (0x80000000)
  #define IRQ_LOAD_CONTEXT_SEQ (0x7fffffff)



  #define check_task_fense(task) (panic_on((task)->fence1 != (task) || ((task)->fence2 != (task)), "task is corrupted"))
  #define check_task_list(task) (panic_on((task)->fwd->bck != (task) || ((task)->bck->fwd != (task)), "task list is corrupted"))

#endif