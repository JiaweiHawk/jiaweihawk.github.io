#include <common.h>
#include <time.h>

int main() {
  ioe_init();
  cte_init(os->trap);
  os->init();
  mpe_init(os->run);


  panic_on(false, "wrong return to main");
  return 1;
}