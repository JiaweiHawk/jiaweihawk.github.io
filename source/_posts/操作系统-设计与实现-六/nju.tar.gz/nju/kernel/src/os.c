#include <os.h>

static void os_init() {
  pmm->init();
  kmt->init();
}


#if defined TESTspin
  static spinlock_t spin = {.lock = 0, .name = "testspinlock"};
  static int res = 0, count = 0;
  #define SIZE 1000000

  static void os_run()
  {
    for(int i = 0; i < SIZE; ++i) {
      kmt->spin_lock(&spin);
      ++res;
      kmt->spin_unlock(&spin);
    }

      kmt->spin_lock(&spin);
      ++count;
      kmt->spin_unlock(&spin);

      while(true) {
        kmt->spin_lock(&spin);
        if(count == cpu_count()) {
          printf("%d\n", res);
          kmt->spin_unlock(&spin);
          break;
        }
        kmt->spin_unlock(&spin);
      }

      while(true) {;}
  }

#elif defined TESTsem0

  static sem_t sem = {.spinlock = {.lock = 0, .name = "testsem"}, .val = 0};
  static int res = 0;
  #define SIZE 10000000
  static void os_run()
  {

    switch (cpu_current()) {
      case 0:
        kmt->sem_wait(&sem);
        printf("%d\n", res);
        break;
      case 1:
        for(int i = 0; i < SIZE; ++i) { ++res; }
        kmt->sem_signal(&sem);
        break;
      default:
        break;
    }


    while(1) {;}
  }


#elif defined TESTsem1

  static sem_t sem = {.spinlock = {.lock = 0, .name = "testsem"}, .val = 1};
  static int res = 0, count = 0;
  #define SIZE 1000000
  static void os_run()
  {

    switch (cpu_current()) {
      default:
        for(int i = 0; i < SIZE; ++i) {
          kmt->sem_wait(&sem);
          ++res;
          kmt->sem_signal(&sem);
        }
        break;
    }

    kmt->sem_wait(&sem);
    if(++count == cpu_count()) { printf("%d\n", res); }
    kmt->sem_signal(&sem);

    while(1) {;}
  }

#elif defined TESTcreate
  void func(void *arg){
    printf("cpu:%s\n", (char*)arg);
    while(1) {yield();}
  }
  static void os_run() {

    printf("cpu #%d\n", cpu_current());

    char *idx = (char*)pmm->alloc(2);
    idx[1] = 0;
    idx[0] = '0' + cpu_current();

    kmt->create(pmm->alloc(sizeof(task_t)), idx, func, (void*)idx);
    while(1) {yield();}
  }

#else

  static void os_run() {
    for (const char *s = "Hello World from CPU #*\n"; *s; s++) {
      putch(*s == '*' ? '0' + cpu_current() : *s);
    }
    while (1) ;
  }

#endif


/*
 * 用来注册一个中断调用时的callback，其不需要线程/中断安全
 * 
 * 其和trap共同管理所有的中断处理程序
 * 由于是动态管理，因此使用链表进行存储
 * 
 * 最简单的，使用有序单向链表，存储注册的中断处理程序，相同的seq，则插入到最开始即可
 */
typedef struct IRQ
{
  int seq;
  int event;
  handler_t handler;
  struct IRQ *next;

} irq_t;

// irqs 为中断处理程序链表的虚表头
static irq_t fake_irq_head = {.next = NULL},  *irqs = &fake_irq_head;


static void
on_irq(int seq, int event, handler_t handler)
{
  assert(handler);

  irq_t *iter = irqs, *irq = (irq_t*)pmm->alloc(sizeof(irq_t));

  panic_on(irq == NULL, "[*] pmm->alloc == NULL");

  //填充irq信息
  irq->seq = seq;
  irq->event = event;
  irq->handler = handler;
  irq->next = NULL;


  //遍历iter，根据seq找到待插入位置的上一个irq_t指针
  while(iter->next && iter->next->seq < seq) { iter = iter->next; }

  panic_on(iter->next == irq, "[*] invalid irq");

  //将当前申请的irq插入到链表中
  irq->next = iter->next;
  iter->next = irq;


  debug("seq:%d event:%d handler:%d\n", seq, event, handler);
}



/*
 * 实现中断处理程序的回调
 * 根据说明文档，其返回且仅返回一个Context
 */
static Context *
trap(Event ev, Context *ctx)
{
  Context *res = NULL;

  irq_t *iter = irqs->next;
  while(iter) {

    //如果其event满足iter所指向的event，回调该处理程序即可
    if(iter->event == EVENT_NULL || iter->event == ev.event) {
      Context *temp_context = iter->handler(ev, ctx);

      panic_on(temp_context && res, "[*] multiple contexts");

      res = temp_context ? temp_context : res;
    }

    iter = iter->next;
  }


  panic_on(res == NULL, "[*] return NULL context");

  debug("event:%s Context:%d Context:%d\n",ev.msg, ctx, res);
  return res;
}



MODULE_DEF(os) = {
  .init = os_init,
  .run  = os_run,
  .trap = trap,
  .on_irq = on_irq,
};