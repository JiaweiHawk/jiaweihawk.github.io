#include <kmt.h>


/*
 * 进程链表是一个双向循环链表
 * 由于这是一个共享资源，并且会涉及到读、写
 * 则需要上一个锁进行保护
 */
static task_t **currents_task_ptr;
static spinlock_t tasks_spinlock, *tasks_spinlock_ptr = &tasks_spinlock;




/*
 * 初始化自旋锁信息
 */
static void
spin_init(spinlock_t *lk, const char *name)
{
  lk->name = name;
  lk->lock = SPINLOCK_UNLOCKED;
}


/*
 * 互斥的获取自旋锁
 * 1. 根据文档说明，在获取锁后，需要关闭中断
 * 2. 在关闭中断之前，需要保存当前中断情况，避免过早打开中断
 */
static void
spin_lock(spinlock_t *lk)
{
  panic_on(lk == NULL, "spin_lock(lk == NULL)");

  /*
  * 如果返回的值是SPINLOCK_LOCKED
  * 说明此时已经有进程获取锁资源了，则需要等到该进程释放掉所资源位置
  */
  while(atomic_xchg(&lk->lock, SPINLOCK_LOCKED) == SPINLOCK_LOCKED) {;}
  debug("%s\n", lk->name);

  /*
   * 获取锁后
   * 首先保存当前中断情况
   * 然后关闭中断即可
   */
  lk->saved_interrupt_status = ienabled();
  iset(false);
}



/*
 * 此时，需要恢复之前的中断情况
 * 互斥的释放锁资源
 */
static void
spin_unlock(spinlock_t *lk)
{
  panic_on(lk == NULL, "spin_unlock(lk == NULL)");

  debug("%s\n", lk->name);

  // 恢复中断情况
  iset(lk->saved_interrupt_status);


  /*
  * 此时只有本进程有该锁资源
  * 因此通过原子指令，直接释放即可
  */
  atomic_xchg(&lk->lock, SPINLOCK_UNLOCKED);
}




/*
 * 初始化信号量信息
 */
static void
sem_init(sem_t *sem, const char *name, int value)
{
  panic_on(sem == NULL, "sem_init(sem == NULL)");

  //为了互斥的访问信号量的信息，初始化信号量上的锁
  kmt->spin_init(&sem->spinlock, name);
  sem->val = value;  
}


/*
 * 互斥的申请信号量
 * 如果当前获取的信号量的值大于0，则证明此时仍然有资源，则返回即可
 * 如果获取的信号量的值等于0，则忙时等待即可
 */
static void
sem_wait(sem_t *sem)
{

  panic_on(sem == NULL, "sem_init(sem == NULL)");

  //互斥的访问信号量的值，直到其值大于等于0
  while(1) {
    kmt->spin_lock(&sem->spinlock);
    if(sem->val > 0) {
      //此时成功获取资源
      --sem->val;
      kmt->spin_unlock(&sem->spinlock);
      break;
    }

    //执行到这里，表明资源不足，切换到其他进程上
    kmt->spin_unlock(&sem->spinlock);
    yield();
  }

  debug("%s\n", sem->spinlock.name);
}




/*
 * 互斥释放信号量
 * 直接申请自旋锁，然后释放信号量即可
 */
static void
sem_signal(sem_t *sem)
{

  panic_on(sem == NULL, "sem_signal(sem == NULL)");

  kmt->spin_lock(&sem->spinlock);
  ++sem->val;
  kmt->spin_unlock(&sem->spinlock);

  debug("%s\n", sem->spinlock.name);
}


/*
 * 保存当前的上下文
 */
static Context *
save_context(Event ev, Context *ctx)
{
  /*
   * 由于要修改当前进程信息，但是仅仅是修改ctx字段，其他处理器不会进行修改或读取，则无需上锁
   */
  task_t *task = currents_task_ptr[cpu_current()];

  debug("cpu[%d] save task %s\n", cpu_current(), task->name);

  check_task_fense(task);
  check_task_list(task);

  task->ctx = ctx;
  return NULL; 
}



/*
 * 进程调度
 */
static Context *
schedule(Event ev, Context *ctx)
{
  /*
   * 首先将程序的上下文进行保存
   * 由于需要更改当前CPU执行的进程信息，需要获取相关的锁
   */
  task_t *task = currents_task_ptr[cpu_current()];
  panic_on(task->status != RUNNING, "invalid task status");


  kmt->spin_lock(tasks_spinlock_ptr);

  task->status = READY;

  /*
   * 此时需要查找可以被调度的进程
   * 这里规则非常简单，只要不是READY状态的，就无法上CPU执行,实际上可以优化IDLE进程，将其分成就绪队列和运行队列等，这里就不实现了
   */
  task = task->fwd;     //避免每一次都调度到当前线程
  while(task->status != READY) { task = task->fwd; }

  check_task_fense(task);
  check_task_list(task);
  task->status = RUNNING;


  kmt->spin_unlock(tasks_spinlock_ptr);


  /*
   * 更改当前CPU的任务，并返回其Context即可
   */
  currents_task_ptr[cpu_current()] = task;
  debug("cpu[%d] load the task %s\n", cpu_current(), task->name);

  return task->ctx;
}


/*
 * 主要初始化进程链表
 * 需要注册处理EVENT_YIELD类型的中断处理程序
 */
static void
init()
{
  //初始化进程链表的自旋锁，访问进程链表时，需要获取锁，从而进行同步
  kmt->spin_init(tasks_spinlock_ptr, "tasks_spinlock_ptr");


  //每一个cpu同样需要记录自己正在执行的task信息，初始时为当前的idle进程
  currents_task_ptr = (task_t **)pmm->alloc(sizeof(task_t*) * cpu_count());
  for(int i = 0; i < cpu_count(); ++i) {
    currents_task_ptr[i] = (task_t*)pmm->alloc(sizeof(task_t));
    currents_task_ptr[i]->fence1 = currents_task_ptr[i]->fence2 = currents_task_ptr[i];
    currents_task_ptr[i]->status = RUNNING;
    currents_task_ptr[i]->ctx = NULL;
    currents_task_ptr[i]->name = "IDLE";
  }


  //  将进程插入到链中，并且指定全局指针
  for(int i = 0; i < cpu_count(); ++i) {
    currents_task_ptr[i]->bck = currents_task_ptr[(i + cpu_count() - 1) % cpu_count()];
    currents_task_ptr[i]->fwd = currents_task_ptr[(i + 1) % cpu_count()];
  }


  // 注册中断处理程序，主要是任何中断，都用来调度进程，也就是进程保存和进程选择
  os->on_irq(IRQ_SAVE_CONTEXT_SEQ, EVENT_NULL, save_context);
  os->on_irq(IRQ_LOAD_CONTEXT_SEQ, EVENT_NULL, schedule);
}


/*
 * 将进程从双向链表中删除
 * 同时释放掉进程申请的资源信息
 */
static void
teardown(task_t *task)
{
  panic_on(task == NULL, "invalid task pointer");

  //测试需要互斥的访问task资源，则获取相关的锁即可
  kmt->spin_lock(tasks_spinlock_ptr);

  panic_on(task->status == RUNNING, "invalid task status");
  check_task_fense(task);
  check_task_list(task);

  //由于task永远不可能是空链表，则不需要考虑删除最后一个元素的情况
  task->bck->fwd = task->fwd;
  task->fwd->bck = task->bck;

  kmt->spin_unlock(tasks_spinlock_ptr);



  //这里具体释放申请的资源
  task->fence1 = task->fence2 = NULL;
  pmm->free(task);
}


/*
 * 创建进程，初始化相关内容，并且将其插入到进程链表中
 */
static int
create(task_t *task, const char *name, void (*entry)(void *arg), void *arg)
{
  panic_on(task == NULL, "invalid task pointer");

  //设置task相关的信息
  task->fence1 = task->fence2 = task;
  task->ctx = kcontext((Area){.start = (void*)task->stack, .end = (void*)(task->stack + STACK_SIZE)}, entry, arg);
  task->name = name;
  task->status = READY;


  debug("create the task:%s\n", task->name);


  /*
   * 由于要添加到进程链表中，因此需要访问相应的锁结构
   * 为了避免饥饿，将新添加的进程放置在最后
   */
  kmt->spin_lock(tasks_spinlock_ptr);
  task_t *fwd = currents_task_ptr[cpu_current()], *bck = fwd->bck;

  check_task_fense(bck);
  check_task_list(bck);
  check_task_fense(fwd);
  check_task_list(fwd);

  task->fwd = fwd; task->bck = bck;
  bck->fwd = fwd->bck = task;
  kmt->spin_unlock(tasks_spinlock_ptr);

  return 0;
}



MODULE_DEF(kmt) = {
  .init = init,
  .create = create,
  .teardown = teardown,
  .spin_init = spin_init,
  .spin_lock = spin_lock,
  .spin_unlock = spin_unlock,
  .sem_init = sem_init,
  .sem_wait = sem_wait,
  .sem_signal = sem_signal,
};