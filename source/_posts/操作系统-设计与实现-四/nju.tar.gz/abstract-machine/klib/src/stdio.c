#include <am.h>
#include <klib.h>
#include <klib-macros.h>
#include <stdarg.h>

#if !defined(__ISA_NATIVE__) || defined(__NATIVE_USE_KLIB__)

#define __FORMAT_NORMAl (0)
#define __FORMAT_TRANSLATE (1)
static char *itoa(char *str, int val) {
	//int最多32位，十进制10位左右
	char stack[16] = {0}, minus = 0;
	int sp = 0;

	if(val < 0) {
		minus = 1;
		val = -val;
	}


	while(val) {
		stack[sp++] = val % 10;
		val /= 10;
	}


	int idx = 0;
	if(minus) { str[idx++] = '-'; }

	if(sp) {
		while(sp--) { str[idx++] = '0' + stack[sp]; }
	}else { str[idx++] = '0'; }
	str[idx] = 0;

	return str;
}



int printf(const char *fmt, ...) {
	va_list ap;
	int number = 0;
	char temp[16];
	unsigned char state = __FORMAT_NORMAl;


	va_start(ap, fmt);
	for(size_t i = 0; fmt[i]; ++i) {
		switch(state) {
			case __FORMAT_NORMAl:
				if(fmt[i] == '%') { state = __FORMAT_TRANSLATE; }
				else { putch(fmt[i]);}
				break;
			case __FORMAT_TRANSLATE:
				state = __FORMAT_NORMAl;
				switch(fmt[i]) {
					case '%':
						putch('%');
						break;
					case 'c':
						putch((char)va_arg(ap, int));
						++number;
						break;
					case 'd':
						putstr(itoa(temp, va_arg(ap, int)));
						++number;
						break;
					case 's':
						putstr(va_arg(ap, char*));
						++number;
						break;
					//这里default表示标准库未定义行为
					default:
						break;
				}
				break;
			default:
				break;
		}
	}
	va_end(ap);

	return number;
}


int vsprintf(char *out, const char *fmt, va_list ap) {
  panic("Not implemented");
}

int sprintf(char *out, const char *fmt, ...) {
  panic("Not implemented");
}

int snprintf(char *out, size_t n, const char *fmt, ...) {
  panic("Not implemented");
}

int vsnprintf(char *out, size_t n, const char *fmt, va_list ap) {
  panic("Not implemented");
}

#endif
