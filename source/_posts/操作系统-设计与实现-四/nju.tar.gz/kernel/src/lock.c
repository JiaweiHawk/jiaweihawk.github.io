#include <common.h>


#define locked		(0)
#define unlocked	(1)



/*
 * 上锁
 * 如果上锁成功，则程序可以独占资源，直到主动释放锁
 * 如果上锁失败，则直接返回，不会重新尝试(即非自旋锁)
 */
bool lock(lock_t *lk) {
	return atomic_xchg(lk, locked) == unlocked;
}


/*
 * 释放锁
 * 即释放之前上的锁，释放独占资源
 */
void unlock(lock_t *lk) {
	atomic_xchg(lk, unlocked);
}


/*
 * 初始化锁
 * 即将锁的值更改为unlocked
 */
void lock_init(lock_t *lk) {
	unlock(lk);
}
