#include <common.h>


/*
 * 通用的工具函数
 */
//计算ceil(log_{a}^{n})
#define BITPERCHAR 8
static inline int64_t log_ceil(int64_t a, int64_t n) {
	//因为a > 1，则直接取a = 2即可
	assert(a > 1 && n >= 0);

	//为了避免n恰好为2的幂指数，首先减1在计算，不会影响非2的幂指数的计算结果
	--n;

	int64_t left = 0, right = sizeof(int64_t) / sizeof(char) * BITPERCHAR - 1;

	while(left <= right) {
		int middle = left + (right - left) / 2;
		if(n >> middle) { left = middle + 1; }
		else { right = middle - 1; }
	}

	return left;
}



/*
 * 将内存的请求大小对齐到2 ^ {i}
 */
#ifndef TEST
static
#endif
size_t request2size(size_t req) {
	return ((size_t)1) << log_ceil(2, req);
}




/*
 * 设置Buddy算法的相关参数
 */
#define B  * (1)
#define KB * (1024)
#define MB * (1024 KB)
#define LOG_PAGE_SIZE (12)
#define PAGE_SIZE (1 << LOG_PAGE_SIZE)
#define MAX_SIZE  (16 MB)



/*
 * 初始化Buddy结构
 * 一开始默认所有的内存对象都属于最大下所对应的内存对象
 * 初始化对应的映射结构、锁结构等
 */
typedef struct MALLOC_CHUNK {
	//当内存对象处于未使用、或被free时，通过 MALLOC_CHUNK来管理
	struct MALLOC_CHUNK *fd;
	struct MALLOC_CHUNK *bk;	//该字段仅在buddy的双向链表结构中使用，slab中不使用该字段
} Malloc_Chunk;

typedef struct BUDDY {
	Malloc_Chunk *ptr_list;		//即指向buddy的双向链表的表头数组
	unsigned char *ptr_page2idx;	//将虚拟地址对应的虚拟页根据其内存对象的大小，映射到所属的表头数组对应的下标中
	uintptr_t startAddress;		//即虚拟地址在ptr_page2idx数组的下标为:(address - startAddress) >> LOG_PAGE_SIZE
	lock_t lock_buddy;		//buddy结构体中的双向链表的表头数组的锁
	int buddy_size;			//即双向链表的表头数组的个数
} Buddy;


//buddy相关的宏操作
#define buddy_ptr_list_at(buddy, idx) (((Malloc_Chunk*)((buddy)->ptr_list)) + (idx))
#define buddy_get_chunk_use_flag(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] >> (sizeof(unsigned char) * 8 - 1))
#define buddy_set_chunk_used(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] |= (((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)))
#define buddy_set_chunk_unused(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] &= ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)) - 1))
#define buddy_get_idx(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] & ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)) - 1))
#define buddy_set_idx(buddy, address, idx) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] = ((idx) | (((uint64_t)buddy_get_chunk_use_flag((buddy), (address))) << (sizeof(unsigned char) * 8 - 1))))


#ifndef TEST
static
#endif
Buddy *buddy = (Buddy*)NULL;


//将节点从双向循环链表中摘下来
static void list_remove(Malloc_Chunk *malloc_chunk) {
	//确保当前链表元素个数一个(因为始终会有一个表头)
	assert(malloc_chunk && malloc_chunk->fd != malloc_chunk);

	assert(malloc_chunk->fd->bk == malloc_chunk && malloc_chunk->bk->fd == malloc_chunk);

	Malloc_Chunk *fwd = malloc_chunk->fd, *bck = malloc_chunk->bk;

	fwd->bk = bck;
	bck->fd = fwd;
}
//将节点插入到bin和bin->fd之间
static void list_insert(Malloc_Chunk *bin, Malloc_Chunk *malloc_chunk) {

	//确认参数都有效
	assert(malloc_chunk && bin);

	//确认bin是有效的双向链表
	assert(bin->fd->bk == bin && bin->bk->fd == bin);

	Malloc_Chunk *bck = bin, *fwd = bin->fd;
	bck->fd = malloc_chunk;
	fwd->bk = malloc_chunk;
	malloc_chunk->fd = fwd;
	malloc_chunk->bk = bck;
}

//	初始化buddy相关的数据结构信息
static int64_t buddy_init(void) {

	//首先将heap.start和heap.end对齐到16MB，并且将heap.start偏移16MB，方便保留相关的数据
	uintptr_t heapStart = (((uintptr_t)heap.start) + 2 * MAX_SIZE - 1) & (~(MAX_SIZE - 1)), heapEnd = ((uintptr_t)heap.end) & (~(MAX_SIZE - 1));


	//即双链表的表头数组
	Malloc_Chunk *malloc_chunk = (Malloc_Chunk*)(heap.start + sizeof(Buddy));


	//其buddy_size即倍增的双链表的个数，同样也是双链表的表头数组的元素个数，即0、1、...、log_ceil(2, MAX_SIZE / PAGE_SIZE)
	int buddy_size = log_ceil(2, MAX_SIZE / PAGE_SIZE) + 1;


	//其次是ptr_page2idx，这里为了实现简单，直接将一个页的状态以一个unsigned char表示。因为双链表元素个数最多log_ceil(MAX_SIZE / PAGE_SIZE)，因此unsigned char完全足够表示(这里4bit即可)
	unsigned char *ptr_page2idx = (unsigned char *)(heap.start + sizeof(Buddy) + buddy_size * sizeof(Malloc_Chunk));


	//填充buddy全局变量
	buddy->ptr_list = malloc_chunk;
	buddy->ptr_page2idx = ptr_page2idx;
	buddy->startAddress = heapStart;
	buddy->buddy_size = buddy_size;
	lock_init(&(buddy->lock_buddy));


	//初始化双向链表
	for(int i = 0; i < buddy_size; ++i) {
		malloc_chunk[i].fd = malloc_chunk[i].bk = malloc_chunk + i;
	}


	//初始化内存对象，将内存以允许的最大内存大小进行切割
	uintptr_t chunk = heapStart;
	Malloc_Chunk *lastbin = buddy_ptr_list_at(buddy, buddy_size - 1);
	while(chunk < heapEnd) {

		//首先设置内存的映射关系
		buddy_set_idx(buddy, chunk, buddy_size - 1);
		buddy_set_chunk_unused(buddy, chunk);

		//接着将该内存对象插入到双向链表数组中
		list_insert(lastbin, (Malloc_Chunk*)chunk);

		chunk += MAX_SIZE;
	}



	return sizeof(Buddy) + buddy_size * sizeof(Malloc_Chunk) + sizeof(unsigned char) * (heapEnd - heapStart) / PAGE_SIZE;
}



/*
 * 从Buddy伙伴中直接获取不小于PAGE_SIZE、不大于MAX_SIZE的内存对象即可，并且请求大小已经对齐
 */

#ifndef TEST
static
#endif
void *buddy_malloc(size_t size) {

	//确保请求大小合规
	assert(size >= PAGE_SIZE && size <= MAX_SIZE && !(size & (size - 1)));


	//获取自旋锁 
	while(!lock(&(buddy->lock_buddy))) {;}


	int idx = log_ceil(2, size >> LOG_PAGE_SIZE);

	//如果当前buddy中包含该大小的内存对象，则直接返回该对象即可
	Malloc_Chunk *bin = buddy_ptr_list_at(buddy, idx);
	if(bin->bk != bin) {
		void *victim = bin->bk;
		list_remove(victim);
		buddy_set_chunk_used(buddy, victim);

		unlock(&(buddy->lock_buddy));
		return victim;
	}else {
		//首先找到大于当前下标的可用的内存对象
		Malloc_Chunk *split = NULL;
		int splitIndex = idx + 1;
		for(; splitIndex < buddy->buddy_size; ++splitIndex) {
			bin = buddy_ptr_list_at(buddy, splitIndex);
			if(bin->bk != bin) {
				split = bin->bk;
				assert(!buddy_get_chunk_use_flag(buddy, split));
				list_remove(split);
				break;
			}
		}


		if(split) {
			//将split对应的内存对象分割到符合条件的大小即可
			while(splitIndex-- != idx) {
				Malloc_Chunk *remainder = (Malloc_Chunk*)(((uintptr_t)split) + (1 << splitIndex) * PAGE_SIZE);

				list_insert(buddy_ptr_list_at(buddy, splitIndex), remainder);
				buddy_set_chunk_unused(buddy, remainder);
				buddy_set_idx(buddy, remainder, splitIndex);
			}

			buddy_set_chunk_used(buddy, split);
			buddy_set_idx(buddy, split, idx);
			unlock(&(buddy->lock_buddy));
			return split;
		}
	}


	//最后没有符合条件的
	unlock(&(buddy->lock_buddy));
	return NULL;
}


/*
 * 释放对应的内存对象
 * 并且合并符合条件的相邻的内存对象
 */
#ifndef TEST
static
#endif
void buddy_free(void *chunk) {
	//确保释放的内存对象是有效的
	assert(chunk);

	int idx = buddy_get_idx(buddy, chunk);

	//首先确保当前内存对象是被释放的，并且其大小是合法的
	assert(buddy_get_chunk_use_flag(buddy, chunk) && idx < buddy->buddy_size);

	Malloc_Chunk *malloc_chunk = (Malloc_Chunk*)chunk;

	//获取自旋锁 
	while(!lock(&(buddy->lock_buddy))) {;}


	for(; idx + 1 < buddy->buddy_size; ++idx) {
		//获取当前邻接的chunk，通过异或获取
		Malloc_Chunk *adj = (Malloc_Chunk*)(((uintptr_t)malloc_chunk) ^ ((((uint64_t)1) << idx) * PAGE_SIZE));

		//如果当前邻接的chunk符合条件——即是释放的，对应的大小也相等
		if(!buddy_get_chunk_use_flag(buddy, adj) && buddy_get_idx(buddy, adj) == idx) {
			list_remove(adj);

			//获取合并后的内存对象头
			malloc_chunk = malloc_chunk < adj ? malloc_chunk : adj;
		}else {
			//如果当前邻接的chunk不符合条件，则直接退出，将malloc_chunk完成设置并插入双向链表中
			break;
		}
	}


	//将malloc_chunk插入到对应的双向循环链表中
	buddy_set_idx(buddy, malloc_chunk, idx);
	buddy_set_chunk_unused(buddy, malloc_chunk);
	list_insert(buddy_ptr_list_at(buddy, idx), malloc_chunk);
	

	unlock(&(buddy->lock_buddy));
}

static void *kalloc(size_t size) {
  return NULL;
}

static void kfree(void *ptr) {
}

static void pmm_init() {
  uintptr_t pmsize = ((uintptr_t)heap.end - (uintptr_t)heap.start);
  printf("Got %d MiB heap: [%p, %p)\n", pmsize >> 20, heap.start, heap.end);


  buddy = (Buddy*)(heap.start);
  int offset = buddy_init();
  printf("%d\n", offset);
}

MODULE_DEF(pmm) = {
  .init  = pmm_init,
  .alloc = kalloc,
  .free  = kfree,
};
