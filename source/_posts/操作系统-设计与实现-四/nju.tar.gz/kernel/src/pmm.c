#include <common.h>


/*
 * 通用的工具函数
 */
static inline int64_t min(int64_t a, int64_t b) { return a < b ? a : b; }
static inline int64_t max(int64_t a, int64_t b) { return a > b ? a : b; }
//计算ceil(log_{a}^{n})
#define BITPERCHAR 8
static inline int64_t log(int64_t a, int64_t n) {
	//因为a > 1，则直接取a = 2即可
	assert(a > 1 && n >= 0);

	//为了避免n恰好为2的幂指数，首先减1在计算
	--n;

	int64_t left = 0, right = sizeof(int64_t) / sizeof(char) * BITPERCHAR - 1;

	while(left <= right) {
		int middle = left + (right - left) / 2;
		if(n >> middle) { left = middle + 1; }
		else { right = middle - 1; }
	}

	return left;
}


/*
 * 将内存的请求大小对齐到2 ^ {i}
 */
#ifndef TEST
static
#endif
size_t request2size(size_t req) {
	return ((size_t)1) << log(2, req);
}




/*
 * 设置Buddy算法的相关参数
 */
#define B  * (1)
#define KB * (1024)
#define MB * (1 KB)
#define PAGE_SIZE (4096 B)
#define MAX_SIZE  (16 MB)





/*
 * 初始化Buddy结构
 * 将整个内存数组按照倍增规则分配到对应的双向链表的表头数组中
 * 初始化对应的bitmap结构、锁结构等
 */
typedef struct BUDDY {
	lock_t lock_buddy;		//buddy结构体中的双向链表的表头数组的锁
	uintptr_t ptr_list;		//即指向buddy存储双向链表的表头数组
	uintptr_t ptr_bitmap;		//其真实结构为uint8_t ptr_bitmap[buddy_size][对应序号链表的对应的大小]
	int buddy_size;			//即双向链表的表头数组的个数
} Buddy;

typedef struct MALLOC_CHUNK {
	//当内存对象处于未使用、或被free时，通过 MALLOC_CHUNK来管理
	struct MALLOC_CHUNK *fd;
	struct MALLOC_CHUNK *bk;	//该字段仅在buddy的双向链表结构中使用，slab中不使用该字段
} Malloc_Chunk;


#ifndef TEST
static
#endif
Buddy *buddy = (Buddy*)NULL;

#ifndef TEST
static
#endif
int buddy_init(void) {


	buddy = (Buddy*)(heap.start);

	//首先将heap.start和heap.end对齐到16MB
	uintptr_t heapStart = (((uintptr_t)heap.start) + MAX_SIZE - 1) & (MAX_SIZE - 1), heapEnd = (((uintptr_t)heap.start) + MAX_SIZE - 1) & (MAX_SIZE - 1);


	//即双链表的表头数组
	Malloc_Chunk *malloc_chunk = (Malloc_Chunk*)(heapStart + sizeof(Buddy));

	//其buddy_size即倍增的双链表的个数，同样也是双链表的表头数组的元素个数
	int buddy_size = log(2, MAX_SIZE / PAGE_SIZE) + 1;


	//接着是显示内存占用情况的bitmap
	unsigned int 
}


static void *kalloc(size_t size) {
  return NULL;
}

static void kfree(void *ptr) {
}

static void pmm_init() {
  uintptr_t pmsize = ((uintptr_t)heap.end - (uintptr_t)heap.start);
  printf("Got %d MiB heap: [%p, %p)\n", pmsize >> 20, heap.start, heap.end);
}

MODULE_DEF(pmm) = {
  .init  = pmm_init,
  .alloc = kalloc,
  .free  = kfree,
};
