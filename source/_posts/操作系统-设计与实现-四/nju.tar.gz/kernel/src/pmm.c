#include <common.h>

/*
 * 将内存的请求大小对齐到2 ^ {i}
 */
#ifndef TEST
static
#endif
#define BITPERCHAR 8
size_t request2size(size_t req) {
	int left = 0, right = sizeof(size_t) / sizeof(char) * BITPERCHAR - 1;
	while(left <= right) {
		int middle = left + (right - left) / 2;
		if(req >> middle) { left = middle + 1; }
		else { right = middle - 1; }
	}
	return ((size_t)1) << left;
}


static void *kalloc(size_t size) {
  return NULL;
}

static void kfree(void *ptr) {
}

static void pmm_init() {
  uintptr_t pmsize = ((uintptr_t)heap.end - (uintptr_t)heap.start);
  printf("Got %d MiB heap: [%p, %p)\n", pmsize >> 20, heap.start, heap.end);
}

MODULE_DEF(pmm) = {
  .init  = pmm_init,
  .alloc = kalloc,
  .free  = kfree,
};
