#include <common.h>

#ifndef TEST

int main() {
  os->init();
  mpe_init(os->run);
  return 1;
}

#else

static int itoa(const char *a) {
	int res = 0;
	int isSigned = 1, idx = 0;

	if(a[idx] == '+' || a[idx] == '-') { isSigned == (a[idx++] == '-') ? 1 : -1; }
	for(; a[idx]; ++idx) { res = res * 10 + a[idx] - '0'; }

	return isSigned * res;
}


int numberOfFinishedCpu = 0;
lock_t lock_numberOfFinishedCpu;

static void valid(int idx, bool condition, char *message) {

	if(condition) { printf("[%d] is \033[32mcorrect\033[0m\n%s\n", idx, message); }
	else { printf("[%d] is \033[31mwrong\033[31m\n%s\n", idx, message); }
	halt(0);
}


/*
 * 测试锁结构
 */
int test1_sum = 0, test1_count = 1000000000;
lock_t test1_lock;

void test1() {
	if(cpu_current()) {
		for(int i = 0; i < test1_count; ++i) {
			while(!lock(&test1_lock)) {
				++test1_sum;
				unlock(&test1_lock);
			}
		}

		while(!lock(&lock_numberOfFinishedCpu)) {
			++numberOfFinishedCpu;
			unlock(&lock_numberOfFinishedCpu);
		}

		while(1) {;}
	}else { 

		//等待所有进程执行结束
		while(true) {
			if(lock(&lock_numberOfFinishedCpu)) {
				if(numberOfFinishedCpu + 1 == cpu_count()) {
					break;
				}
				unlock(&lock_numberOfFinishedCpu);
			}
		}

		valid(1, test1_sum == test1_count * (cpu_count() - 1), "test the lock");
	}

}

int main(int argc, char *argv[]) {
	if(argc < 2) { halt(1); }

	os->init();
	lock_init(&lock_numberOfFinishedCpu);

			lock_init(&test1_lock);
			mpe_init(test1);
		
	switch(itoa(argv[1])) {
		case 0:
			valid(0, true, "build the test frame");
			break;
		case 1:
			lock_init(&test1_lock);
			mpe_init(test1);
		default:
			break;
	}
	return 0;
}

#endif
