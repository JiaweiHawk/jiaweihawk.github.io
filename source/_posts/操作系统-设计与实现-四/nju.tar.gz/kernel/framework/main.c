#include <common.h>
#include <time.h>

#ifndef IDX
int main() {
	os->init();
	mpe_init(os->run); return 1;
}

#else


/*
 * 判断测试样例是否正确
 */
#define RED(s) ("\033[31m" s "\033[0m")
#define GREEN(s) ("\033[32m" s "\033[0m")
#define check(idx, condition, message) CHECK(idx, condition, message, __LINE__)
static void CHECK(int idx, bool condition, const char *message, int line) {
	if(condition) { printf(GREEN("[%d] is correct\n%s\n"), idx, message); }
	else { printf(RED("line:%d\n[%d] is incorrect\n%s\n"), line, idx, message); }
	halt(0);
}


/*
 * 测试样例0
 * 测试框架是否正确
 */
static void test0() {
	if(!cpu_current()) { check(0, true, "test the tesing framework"); }
	else {
		while(true) {;}
	}
}


/*
 * 确保所有进程都执行完其函数
 */
int numberOfFinished = 0;
lock_t lock_numberOfFinished;


/*
 * 测试样例1
 * 测试互斥锁是否正确
 */
volatile int test1_sum = 0;
int test1_count = 1000000;
lock_t lock_test1_sum;
static void test1() {
	if(!cpu_current()) {
		while(true) {
			while(!lock(&lock_numberOfFinished)) {;}
			if(numberOfFinished + 1 == cpu_count()) { check(1, test1_count * numberOfFinished == test1_sum, "test the lock"); }
			unlock(&lock_numberOfFinished);
		}
	}else {
		for(int i = 0; i < test1_count; ++i) {
			while(!lock(&lock_test1_sum)) {;}
			++test1_sum;
			unlock(&lock_test1_sum);
		}

		while(!lock(&lock_numberOfFinished)) {;}
		++numberOfFinished;
		unlock(&lock_numberOfFinished);

		while(1) {;}

	}
}


/*
 * 测试样例二
 * 测试对齐2 ^ {i} 的函数request2size函数是否正确
 */
extern size_t request2size(size_t req);
void test2() {

	
	for(int i = 0; i < 100; ++i) {
		size_t req = rand() % 128, size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}
	for(int i = 0; i < 100; ++i) {
		size_t req = 128 + (rand() % 4096), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}
	for(int i = 0; i < 100; ++i) {
		size_t req = rand(), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}


	for(int i = 0; i < 100; ++i) {
		size_t req = 1 << (rand() % 31), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}

	check(2, true, "test the request2size(size_t req)");
}


/*
 * 测试样例三
 * 测试buddy初始化情况
 */
#define B  * (1)
#define KB * (1024)
#define MB * (1024 KB)
#define PAGE_SIZE (4096 B)
#define LOG_PAGE_SIZE (12)
#define MAX_SIZE  (16 MB)
typedef struct MALLOC_CHUNK {
	//当内存对象处于未使用、或被free时，通过 MALLOC_CHUNK来管理
	struct MALLOC_CHUNK *fd;
	struct MALLOC_CHUNK *bk;	//该字段仅在buddy的双向链表结构中使用，slab中不使用该字段
} Malloc_Chunk;

typedef struct BUDDY {
	Malloc_Chunk *ptr_list;		//即指向buddy的双向链表的表头数组
	unsigned char *ptr_page2idx;		//将虚拟地址对应的虚拟页根据其内存对象的大小，映射到所属的表头数组对应的下标中
	uintptr_t startAddress;		//即虚拟地址在ptr_page2idx数组的下标为:(address - startAddress) >> LOG_PAGE_SIZE
	lock_t lock_buddy;		//buddy结构体中的双向链表的表头数组的锁
	int buddy_size;			//即双向链表的表头数组的个数
} Buddy;

#define buddy_ptr_list_at(buddy, idx) (((Malloc_Chunk*)((buddy)->ptr_list)) + (idx))
#define buddy_chunk_is_used (0x1)
#define buddy_get_chunk_use_flag(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] >> (sizeof(unsigned char) * 8 - 1))
#define buddy_set_chunk_used(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] |= (((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)))
#define buddy_set_chunk_unused(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] &= ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)) - 1))
#define buddy_get_idx(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] & ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 1)) - 1))
#define buddy_set_idx(buddy, address, idx) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] = ((idx) | (((uint64_t)buddy_get_chunk_use_flag((buddy), (address))) << (sizeof(unsigned char) * 8 - 1))))


extern Buddy *buddy;

/*
 * 测试样例三
 * 测试buddy的ptr_page2idx相关的宏
 */
void test3() {
	printf("buddy->ptr_page2idx(buddy->startAddress) = %x\n", buddy->ptr_page2idx[0]);
	if(buddy->ptr_page2idx[0] + 1 != buddy->buddy_size) { check(3, false, "test the buddy macro"); }

	buddy_set_chunk_used(buddy, buddy->startAddress);
	if(!(buddy->ptr_page2idx[0] >> 7) || buddy_get_chunk_use_flag(buddy, buddy->startAddress) != buddy_chunk_is_used) { check(3, false, "test the buddy macro"); }
	printf("buddy->ptr_page2idx(buddy->startAddress) = %x\n", buddy->ptr_page2idx[0]);


	buddy_set_idx(buddy, buddy->startAddress, 0);
	if(buddy->ptr_page2idx[0] != 0x80 || buddy_get_chunk_use_flag(buddy, buddy->startAddress) != buddy_chunk_is_used || buddy_get_idx(buddy, buddy->startAddress)) { check(3, false, "test the buddy macro"); }
	printf("buddy->ptr_page2idx(buddy->startAddress) = %x\n", buddy->ptr_page2idx[0]);

	check(3, true, "test the buddy macro");
}


/*
 * 测试样例四
 * 测试buddy初始化情况
 */
void test4() {
	if(buddy->startAddress & (MAX_SIZE - 1)) { check(4, false, "test the buddy_init()"); }
	printf("buddy->ptr_list:%#016x\nbuddy->ptr_page2idx:%#016x\nbuddy->startAddress:%#016x\nbuddy->buddy_size:%d\n", buddy->ptr_list, buddy->ptr_page2idx, buddy->startAddress, buddy->buddy_size);

	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(i + 1 < buddy->buddy_size && (buddy_ptr_list_at(buddy, i)->fd != buddy_ptr_list_at(buddy, i) || buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i))) { check(4, false, "test the buddy_init()"); }
		if(i + 1 == buddy->buddy_size) {
			Malloc_Chunk *chunk = buddy_ptr_list_at(buddy, i)->fd;
			while(chunk != buddy_ptr_list_at(buddy, i)) {
				if(chunk->bk->fd != chunk) {check(4, false, "test the buddy_init()");}
				if(buddy->ptr_page2idx[((uintptr_t)chunk - buddy->startAddress) >> LOG_PAGE_SIZE] != buddy->buddy_size - 1) {check(4, false, "test the buddy_init()");}
				chunk = chunk->fd;
			}
		}
		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}


	check(4, true, "test the buddy_init()");
}


/*
 * 测试样例5
 * 测试buddy_malloc(size_t size)
 */
void *test5_chunk = NULL;
extern void *buddy_malloc(size_t size);
void test5() {
	test5_chunk = buddy_malloc((1 << (rand() % (buddy->buddy_size - 1))) * PAGE_SIZE); 
	if(!test5_chunk) { check(5, false, "test the buddy_malloc(size_t size)"); }
	int idx = buddy_get_idx(buddy, test5_chunk);

	printf("chunk:%#016x\tidx in ptr_page2idx:%d\tsize:%x\n", test5_chunk, idx, (1 << idx) * PAGE_SIZE);


	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(i < idx && buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i)) { check(5, false, "test the buddy_malloc(size_t size)");}
		if(i >= idx && i + 1 < buddy->buddy_size && (buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i) || buddy_ptr_list_at(buddy, i)->bk->bk != buddy_ptr_list_at(buddy, i) || buddy->ptr_page2idx[((uintptr_t)(buddy_ptr_list_at(buddy, i)->bk) - buddy->startAddress) >> LOG_PAGE_SIZE] != i || buddy_get_chunk_use_flag(buddy, buddy_ptr_list_at(buddy, i)->bk) == buddy_chunk_is_used)) { check(5, false, "test the buddy_malloc(size_t size)"); }
		if(i + 1 == buddy->buddy_size && (buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i) || buddy_ptr_list_at(buddy, i)->bk->bk == buddy_ptr_list_at(buddy, i) || buddy->ptr_page2idx[((uintptr_t)(buddy_ptr_list_at(buddy, i)->bk) - buddy->startAddress) >> LOG_PAGE_SIZE] != i)) { check(5, false, "test the buddy_malloc(size_t size)"); }

		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}

	check(5, true, "test the buddy_malloc(size_t size)");
}




/*
 * 测试样例6
 * 测试buddy_free(void *chunk)
 */
void *test6_chunk = NULL;
extern void buddy_free(void *chunk);
void test6() {
	test6_chunk = buddy_malloc((1 << (rand() % (buddy->buddy_size - 1))) * PAGE_SIZE); 
	if(!test6_chunk) { check(6, false, "test the buddy_free(void *chunk)"); }
	int idx = buddy_get_idx(buddy, test6_chunk);

	printf("chunk:%#016x\tidx in ptr_page2idx:%d\tsize:%x\n", test6_chunk, idx, (1 << idx) * PAGE_SIZE);


	buddy_free(test6_chunk);
	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(i + 1 < buddy->buddy_size && buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i)) { check(6, false, "test the buddy_free(void *chunk)"); }

		if(i + 1 == buddy->buddy_size) {
			Malloc_Chunk *chunk = buddy_ptr_list_at(buddy, i)->fd;
			while(chunk != buddy_ptr_list_at(buddy, i)) {
				if(chunk->bk->fd != chunk) { check(6, false, "test the buddy_free(void *chunk)");}
				if(buddy_get_chunk_use_flag(buddy, chunk) == buddy_chunk_is_used || buddy_get_idx(buddy, chunk) != i) { check(6, false, "test the buddy_free(void *chunk)"); }
				chunk = chunk->fd;
			}
		}
		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}

	check(6, true, "test the buddy_free(void *chunk)");
}



/*
 * 测试样例7
 * 测试buddy_free(void *chunk)
 */
void *test7_chunk = NULL;
void *test7_chunk1 = NULL;
extern void buddy_free(void *chunk);
void test7() {
	test7_chunk = buddy_malloc((1 << (rand() % (buddy->buddy_size - 1))) * PAGE_SIZE); 
	if(!test7_chunk) { check(7, false, "test the buddy_free(void *chunk)"); }
	int idx = buddy_get_idx(buddy, test7_chunk), idx1 = idx + 2;

	test7_chunk1 = buddy_malloc((1 << idx1) * PAGE_SIZE);
	printf("chunk:%#016x\tidx in ptr_page2idx:%d\tsize:%x\nchunk1:%#016x\tidx in ptr_page2idx:%d\tsize:%x\n", test7_chunk, idx, (1 << idx) * PAGE_SIZE, test7_chunk1, idx1, (1 << idx1) * PAGE_SIZE);


	buddy_free(test7_chunk);
	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(i < idx1 && buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i)) { check(7, false, "test the buddy_free(void *chunk)"); }

		if(i >= idx1 && i + 1 < buddy->buddy_size && (buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i) || buddy_get_chunk_use_flag(buddy, buddy_ptr_list_at(buddy, i)->bk) == buddy_chunk_is_used || buddy_get_idx(buddy, buddy_ptr_list_at(buddy, i)->bk) != i)) { check(6, false, "test the buddy_free(void *chunk)"); }
		if(i + 1 == buddy->buddy_size) {
			Malloc_Chunk *chunk = buddy_ptr_list_at(buddy, i)->fd;
			while(chunk != buddy_ptr_list_at(buddy, i)) {
				if(chunk->bk->fd != chunk) { check(7, false, "test the buddy_free(void *chunk)");}
				if(buddy_get_chunk_use_flag(buddy, chunk) == buddy_chunk_is_used || buddy_get_idx(buddy, chunk) != i) { check(7, false, "test the buddy_free(void *chunk)"); }
				chunk = chunk->fd;
			}
		}
		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}

	check(7, true, "test the buddy_free(void *chunk)");
}




/*
 * 测试样例8
 * 测试slab_init(uint64_t offset)
 */
typedef struct SLAB_PER_CPU {
	int slab_size;		//即当前存储的slab种数
	lock_t *locks;		//为了尽可能的高效，每一种slab，分配一把锁
	uintptr_t slabs;	//存储着当前cpu下所有的slab，可以简单理解为slab表头数组，可以简单理解为((Malloc_Chunk*)(((uintptr_t)(slabs)) + log_ceil(2, (size / sizeof(uintptr_t) / 8))))->fd存储的就是slab中具体的内存对象
} Slab_Per_Cpu;


extern Slab_Per_Cpu *slab_cpus;


#define slab_get_cpu(slab_cpus, i)	(((Slab_Per_Cpu*)(slab_cpus)) + (i))
#define slab_cpu_get_lock(slab, idx)	(((Slab_Per_Cpu*)(slab))->locks + (idx))
#define slab_cpu_get_slabs(slab, idx)	((Malloc_Chunk*)(((Slab_Per_Cpu*)(slab))->slabs + (idx) * sizeof(uintptr_t)))

uint64_t qexp(uint64_t base, uint64_t exp) {
	uint64_t res = 1;
	while(exp) {
		if(exp & 1) { res = res * base; }

		base = base * base;
		exp >>= 1;
	}

	return res;
}


void test8() {
	for(int i = 0; i < cpu_count(); ++i) {
		Slab_Per_Cpu *slab = slab_get_cpu(slab_cpus, i);

		if(slab == NULL) { check(8, false, "test the slab_init(uintptr_t ofset)"); }
		printf("slab%d: %p\n", i, slab);


		if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(8, false, "test the slab_init(uintptr_t ofset)"); }

		printf("slabs:\n");
		for(int j = 0; j < slab->slab_size; ++j) {
			printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
			if(slab_cpu_get_slabs(slab, j)->fd != NULL) { check(8, false, "test the slab_init(uintptr_t ofset)"); }
		}
	}


	check(8, true, "test the slab_init(uintptr_t ofset)");
}




/*
 * 测试样例9
 * 测试slab_malloc中相关的宏
 */
#define slab_chunk_is_used (0x3)
#define slab_get_chunk_use_flag(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] >> (sizeof(unsigned char) * 8 - 2))
#define slab_set_chunk_used(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] |= (((uint64_t)0x3) << (sizeof(unsigned char) * 8 - 2)))
#define slab_get_idx(buddy, address) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] & ((((uint64_t)1) << (sizeof(unsigned char) * 8 - 2)) - 1))
#define slab_set_idx(buddy, address, idx) (((Buddy*)(buddy))->ptr_page2idx[(((uintptr_t)(address)) - ((Buddy*)(buddy))->startAddress) >> LOG_PAGE_SIZE] = ((idx) | (((uint64_t)slab_get_chunk_use_flag((buddy), (address))) << (sizeof(unsigned char) * 8 - 2))))
void test9() {
	printf("buddy->ptr_page2idx(buddy->startAddress) = %x\n", buddy->ptr_page2idx[0]);

	slab_set_chunk_used(buddy, buddy->startAddress);
	if(!(buddy->ptr_page2idx[0] >> 6) || buddy_get_chunk_use_flag(buddy, buddy->startAddress) != buddy_chunk_is_used) { check(9, false, "test the slab macro"); }
	printf("buddy->ptr_page2idx(buddy->startAddress) = %x\n", buddy->ptr_page2idx[0]);


	slab_set_idx(buddy, buddy->startAddress, 0);
	if(buddy->ptr_page2idx[0] != 0xc0 || slab_get_chunk_use_flag(buddy, buddy->startAddress) != slab_chunk_is_used || slab_get_idx(buddy, buddy->startAddress)) { check(9, false, "test the slab macro"); }
	printf("buddy->ptr_page2idx(buddy->startAddress) = %x\n", buddy->ptr_page2idx[0]);

	check(9, true, "test the slab macro");
}



/*
 * 测试样例10
 * 测试slab_malloc(size_t size)
 */
#define BITPERCHAR 8
static inline int64_t log_ceil(int64_t a, int64_t n) {
	//因为a > 1，则直接取a = 2即可
	assert(a > 1 && n >= 0);

	//为了避免n恰好为2的幂指数，首先减1在计算，不会影响非2的幂指数的计算结果
	--n;

	int64_t left = 0, right = sizeof(int64_t) / sizeof(char) * BITPERCHAR - 1;

	while(left <= right) {
		int middle = left + (right - left) / 2;
		if(n >> middle) { left = middle + 1; }
		else { right = middle - 1; }
	}

	return left;
}
extern void *slab_malloc(size_t size);
void test10(void) {
	int size = request2size(rand() % 1024), idx = log_ceil(2, size / sizeof(uintptr_t));
	void *res = slab_malloc(size);

	printf("slab_malloc(%#x):%p buddy->ptr_page2idx[%p] = %#x\n", size, res, res, slab_get_idx(buddy, res));
	for(int i = 0; i < cpu_count(); ++i) {
		Slab_Per_Cpu *slab = slab_get_cpu(slab_cpus, i);

		if(slab == NULL) { check(10, false, "test the slab_malloc(size_t size)"); }
		printf("slab%d: %p\n", i, slab);


		if(i == cpu_current()) {
			if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(10, false, "test the slab_malloc(size_t size)"); }

			printf("slabs:\n");
			for(int j = 0; j < slab->slab_size; ++j) {
				printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
				if((j == idx && slab_cpu_get_slabs(slab, j)->fd == NULL) || (j != idx && slab_cpu_get_slabs(slab, j)->fd != NULL)) { check(10, false, "test the slab_malloc(size_t size)"); }
			}
		}else {
			if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(10, false, "test the slab_malloc(size_t size)"); }

			printf("slabs:\n");
			for(int j = 0; j < slab->slab_size; ++j) {
				printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
				if(slab_cpu_get_slabs(slab, j)->fd != NULL) { check(10, false, "test the slab_malloc(size_t size)"); }
			}
		}
	}


	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i)) { check(10, false, "test the slab_malloc(size_t size)"); }
		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}

	check(10, true, "test the slab_malloc(size_t size)");
}






/*
 * 测试样例11
 * 测试slab_free(void *chunk)
 */
extern void *slab_free(void *chunk);
void test11(void) {
	int size = request2size(rand() % 1024), idx = log_ceil(2, size / sizeof(uintptr_t));
	void *res = slab_malloc(size);

	printf("slab_malloc(%#x):%p buddy->ptr_page2idx[%p] = %#x\n", size, res, res, slab_get_idx(buddy, res));
	slab_free(res);


	for(int i = 0; i < cpu_count(); ++i) {
		Slab_Per_Cpu *slab = slab_get_cpu(slab_cpus, i);

		if(slab == NULL) { check(11, false, "test the slab_malloc(size_t size)"); }
		printf("slab%d: %p\n", i, slab);


		if(i == cpu_current()) {
			if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(11, false, "test the slab_malloc(size_t size)"); }

			printf("slabs:\n");
			for(int j = 0; j < slab->slab_size; ++j) {
				printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
				if((j == idx && slab_cpu_get_slabs(slab, j)->fd != res) || (j != idx && slab_cpu_get_slabs(slab, j)->fd != NULL)) { check(11, false, "test the slab_malloc(size_t size)"); }
			}
		}else {
			if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(11, false, "test the slab_malloc(size_t size)"); }

			printf("slabs:\n");
			for(int j = 0; j < slab->slab_size; ++j) {
				printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
				if(slab_cpu_get_slabs(slab, j)->fd != NULL) { check(11, false, "test the slab_malloc(size_t size)"); }
			}
		}
	}


	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i)) { check(11, false, "test the slab_malloc(size_t size)"); }
		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}

	check(11, true, "test the slab_malloc(size_t size)");
}





/*
 * 测试样例12
 * 测试kalloc(size_t size)
 */
void test12(void) {
	int choices[2] = {2048, MAX_SIZE};
	int size = rand() % (choices[rand() & 1]);
	void *res = pmm->alloc(size);

	if(request2size(size) < PAGE_SIZE) {
		int idx = log_ceil(2, request2size(size) / sizeof(uintptr_t));
		printf("kalloc(%#x):%p buddy->ptr_page2idx[%p] = %#x\n", size, res, res, slab_get_idx(buddy, res));
		for(int i = 0; i < cpu_count(); ++i) {
			Slab_Per_Cpu *slab = slab_get_cpu(slab_cpus, i);
	
			if(slab == NULL) { check(12, false, "test the kalloc(size_t size)"); }
			printf("slab%d: %p\n", i, slab);
	
	
			if(i == cpu_current()) {
				if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(12, false, "test the slab_malloc(size_t size)"); }
	
				printf("slabs:\n");
				for(int j = 0; j < slab->slab_size; ++j) {
					printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
					if((j == idx && slab_cpu_get_slabs(slab, j)->fd == NULL) || (j != idx && slab_cpu_get_slabs(slab, j)->fd != NULL)) { check(12, false, "test the kalloc(size_t size)"); }
				}
			}else {
				if(slab->locks == NULL || slab->slabs == (uintptr_t)NULL || sizeof(uintptr_t) * qexp(2, slab->slab_size) != PAGE_SIZE) { check(12, false, "test the kalloc(size_t size)"); }
	
				printf("slabs:\n");
				for(int j = 0; j < slab->slab_size; ++j) {
					printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
					if(slab_cpu_get_slabs(slab, j)->fd != NULL) { check(12, false, "test the kalloc(size_t size)"); }
				}
			}
		}
	
	
		for(int i = 0; i < buddy->buddy_size; ++i) {
			if(buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i)) { check(12, false, "test the kalloc(size_t size)"); }
			printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
		}
	}else {
		int idx = log_ceil(2, request2size(size) / PAGE_SIZE);
		printf("kalloc(%#x):%p buddy->ptr_page2idx[%p] = %#x\n", size, res, res, buddy_get_idx(buddy, res));
		for(int i = 0; i < cpu_count(); ++i) {
			Slab_Per_Cpu *slab = slab_get_cpu(slab_cpus, i);
	
			if(slab == NULL) { check(12, false, "test the kalloc(size_t size)"); }
			printf("slab%d: %p\n", i, slab);
	
			printf("slabs:\n");
			for(int j = 0; j < slab->slab_size; ++j) {
				printf("slabs-%d: %p;   slabs[%d] = %p\n", j, slab_cpu_get_slabs(slab, j), j, slab_cpu_get_slabs(slab, j)->fd);
				if(slab_cpu_get_slabs(slab, j)->fd != NULL) { check(12, false, "test the kalloc(size_t size)"); }
			}
	
		}
	
	
		for(int i = 0; i < buddy->buddy_size; ++i) {
			if(i < idx && buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i)) { check(12, false, "test the kalloc(size_t size)"); }
			if(i >= idx && buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i)) { check(12, false, "test the kalloc(size_t size)"); }
			printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
		}
	}
	

	check(12, true, "test the slab_malloc(size_t size)");
}


int main() {
	os->init();
	srand(time(NULL));
	lock_init(&lock_numberOfFinished);
	/*
	 * 这里通过-DIDX=，传递宏参数
	 */
	switch(IDX) {
		case 0:
			mpe_init(test0);
			break;
		case 1:
			lock_init(&lock_test1_sum);
			mpe_init(test1);
		case 2:
			test2();
		case 3:
			test3();
		case 4:
			test4();
		case 5:
			test5();
		case 6:
			test6();
		case 7:
			test7();
		case 8:
			test8();
		case 9:
			test9();
		case 10:
			test10();
		case 11:
			test11();
		case 12:
			test12();
		default:
			break;
	}

	return 0;
}
#endif
