#include <common.h>

#ifndef IDX
int main() {
	os->init();
	mpe_init(os->run); return 1;
}

#else


/*
 * 判断测试样例是否正确
 */
#define RED(s) ("\033[31m" s "\033[0m")
#define GREEN(s) ("\033[32m" s "\033[0m")
#define check(idx, condition, message) CHECK(idx, condition, message, __LINE__)
static void CHECK(int idx, bool condition, const char *message, int line) {
	if(condition) { printf(GREEN("[%d] is correct\n%s\n"), idx, message); }
	else { printf(RED("line:%d\n[%d] is incorrect\n%s\n"), line, idx, message); }
	halt(0);
}


/*
 * 测试样例0
 * 测试框架是否正确
 */
static void test0() {
	if(!cpu_current()) { check(0, true, "test the tesing framework"); }
	else {
		while(true) {;}
	}
}


/*
 * 确保所有进程都执行完其函数
 */
int numberOfFinished = 0;
lock_t lock_numberOfFinished;


/*
 * 测试样例1
 * 测试互斥锁是否正确
 */
volatile int test1_sum = 0;
int test1_count = 1000000;
lock_t lock_test1_sum;
static void test1() {
	if(!cpu_current()) {
		while(true) {
			while(!lock(&lock_numberOfFinished)) {;}
			if(numberOfFinished + 1 == cpu_count()) { check(1, test1_count * numberOfFinished == test1_sum, "test the lock"); }
			unlock(&lock_numberOfFinished);
		}
	}else {
		for(int i = 0; i < test1_count; ++i) {
			while(!lock(&lock_test1_sum)) {;}
			++test1_sum;
			unlock(&lock_test1_sum);
		}

		while(!lock(&lock_numberOfFinished)) {;}
		++numberOfFinished;
		unlock(&lock_numberOfFinished);

		while(1) {;}

	}
}


/*
 * 测试样例二
 * 测试对齐2 ^ {i} 的函数request2size函数是否正确
 */
extern size_t request2size(size_t req);
void test2() {

	
	for(int i = 0; i < 100; ++i) {
		size_t req = rand() % 128, size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}
	for(int i = 0; i < 100; ++i) {
		size_t req = 128 + (rand() % 4096), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}
	for(int i = 0; i < 100; ++i) {
		size_t req = rand(), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}


	for(int i = 0; i < 100; ++i) {
		size_t req = 1 << (rand() % 31), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if(size != req && ((req & size) || !(req & (size >> 1)))) check(2, false, "test the request2size(size_t req)");
	}

	check(2, true, "test the request2size(size_t req)");
}


/*
 * 测试样例三
 * 测试buddy初始化情况
 */
#define B  * (1)
#define KB * (1024)
#define MB * (1024 KB)
#define PAGE_SIZE (4096 B)
#define LOG_PAGE_SIZE (12)
#define MAX_SIZE  (16 MB)
typedef struct MALLOC_CHUNK {
	//当内存对象处于未使用、或被free时，通过 MALLOC_CHUNK来管理
	struct MALLOC_CHUNK *fd;
	struct MALLOC_CHUNK *bk;	//该字段仅在buddy的双向链表结构中使用，slab中不使用该字段
} Malloc_Chunk;

typedef struct BUDDY {
	Malloc_Chunk *ptr_list;		//即指向buddy的双向链表的表头数组
	unsigned char *ptr_page2idx;		//将虚拟地址对应的虚拟页根据其内存对象的大小，映射到所属的表头数组对应的下标中
	uintptr_t startAddress;		//即虚拟地址在ptr_page2idx数组的下标为:(address - startAddress) >> LOG_PAGE_SIZE
	lock_t lock_buddy;		//buddy结构体中的双向链表的表头数组的锁
	int buddy_size;			//即双向链表的表头数组的个数
} Buddy;

#define buddy_ptr_list_at(buddy, idx) (((Malloc_Chunk*)((buddy)->ptr_list)) + (idx))

extern Buddy *buddy;
void test3() {
	if(buddy->startAddress & (MAX_SIZE - 1)) { check(3, false, "test the buddy_init()"); }
	printf("buddy->ptr_list:%#016x\nbuddy->ptr_page2idx:%#016x\nbuddy->startAddress:%#016x\nbuddy->buddy_size:%d\n", buddy->ptr_list, buddy->ptr_page2idx, buddy->startAddress, buddy->buddy_size);

	for(int i = 0; i < buddy->buddy_size; ++i) {
		if(i + 1 < buddy->buddy_size && (buddy_ptr_list_at(buddy, i)->fd != buddy_ptr_list_at(buddy, i) || buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i))) { check(3, false, "test the buddy_init()"); }
		if(i + 1 == buddy->buddy_size) {
			Malloc_Chunk *chunk = buddy_ptr_list_at(buddy, i);
			while(chunk->fd != buddy_ptr_list_at(buddy, i)) {
				if(chunk->fd->bk != chunk) {check(3, false, "test the buddy_init()");}
				if(chunk != buddy_ptr_list_at(buddy, i) && buddy->ptr_page2idx[((uintptr_t)chunk - buddy->startAddress) >> LOG_PAGE_SIZE] != buddy->buddy_size - 1) {check(3, false, "test the buddy_init()");}
				chunk = chunk->fd;
			}
		}
		printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
	}


	check(3, true, "test the buddy_init()");
}


/*
 * 测试样例4
 * 测试buddy_malloc(size_t size)
 */
void *test4_chunk = NULL;
extern void *buddy_malloc(size_t size);
void test4() {
	if(!cpu_current()) {
		while(true) {
			while(!lock(&lock_numberOfFinished)) {;}
			if(numberOfFinished) {break;}
			unlock(&lock_numberOfFinished);
		}

		if(!test4_chunk) { check(4, false, "test the buddy_malloc(size_t size)"); }
		int idx = buddy->ptr_page2idx[((uintptr_t)test4_chunk - buddy->startAddress) >> LOG_PAGE_SIZE];

		printf("chunk:%#016x\tidx in ptr_page2idx:%d\tsize:%x\n", test4_chunk, idx, 1 << idx);


		for(int i = 0; i < buddy->buddy_size; ++i) {
			if(i == 12) { printf("%#016x %#016x\n", buddy_ptr_list_at(buddy, i)->bk->bk,buddy_ptr_list_at(buddy, i)); }
			if(i < idx && buddy_ptr_list_at(buddy, i)->bk != buddy_ptr_list_at(buddy, i)) { check(4, false, "test the buddy_malloc(size_t size)");}
			if(i >= idx && (buddy_ptr_list_at(buddy, i)->bk == buddy_ptr_list_at(buddy, i) || buddy_ptr_list_at(buddy, i)->bk->bk != buddy_ptr_list_at(buddy, i) || buddy->ptr_page2idx[((uintptr_t)(buddy_ptr_list_at(buddy, i)->bk) - buddy->startAddress) >> LOG_PAGE_SIZE] != i)) { check(4, false, "test the buddy_malloc(size_t size)"); }

			printf("&buddy->ptr_list[%d] = %#016x\tbuddy->ptr_list[%d].fd = %#016x\tbuddy->ptr_list[%d].bk = %#016x\n", i, buddy_ptr_list_at(buddy, i), i, buddy_ptr_list_at(buddy, i)->fd, i, buddy_ptr_list_at(buddy, i)->bk);
		}

		check(4, true, "test the buddy_malloc(size_t size)");

	}else if(cpu_current() == 1) {
		test4_chunk = buddy_malloc((1 << (rand() % (buddy->buddy_size - 1))) * PAGE_SIZE); 
		while(!lock(&lock_numberOfFinished)) {;}
		++numberOfFinished;
		unlock(&lock_numberOfFinished);
	}
	while(1) {;}
}


int main() {
	os->init();

	lock_init(&lock_numberOfFinished);
	/*
	 * 这里通过-DIDX=，传递宏参数
	 */
	switch(IDX) {
		case 0:
			mpe_init(test0);
			break;
		case 1:
			lock_init(&lock_test1_sum);
			mpe_init(test1);
		case 2:
			test2();
		case 3:
			test3();
		case 4:
			mpe_init(test4);
		default:
			break;
	}

	return 0;
}
#endif
