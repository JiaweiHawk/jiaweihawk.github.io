#include <common.h>

#ifndef IDX
int main() {
	os->init();
	mpe_init(os->run); return 1;
}

#else


/*
 * 判断测试样例是否正确
 */
static void check(int idx, bool condition, const char *message) {
	if(condition) { printf("\033[32m[%d] is correct\n%s\033[0m\n", idx, message); }
	else { printf("\033[31m[%d] is incorrect\n%s\033[0m\n", idx, message); }
	halt(0);
}


/*
 * 测试样例0
 * 测试框架是否正确
 */
static void test0() {
	if(!cpu_current()) { check(0, true, "test the tesing framework"); }
	else {
		while(true) {;}
	}
}


/*
 * 确保所有进程都执行完其函数
 */
int numberOfFinished = 0;
lock_t lock_numberOfFinished;


/*
 * 测试样例1
 * 测试互斥锁是否正确
 */
volatile int test1_sum = 0;
int test1_count = 1000000;
lock_t lock_test1_sum;
static void test1() {
	if(!cpu_current()) {
		while(true) {
			while(!lock(&lock_numberOfFinished)) {;}
			if(numberOfFinished + 1 == cpu_count()) { check(1, test1_count * numberOfFinished == test1_sum, "test the lock"); }
			unlock(&lock_numberOfFinished);
		}
	}else {
		for(int i = 0; i < test1_count; ++i) {
			while(!lock(&lock_test1_sum)) {;}
			++test1_sum;
			unlock(&lock_test1_sum);
		}

		while(!lock(&lock_numberOfFinished)) {;}
		++numberOfFinished;
		unlock(&lock_numberOfFinished);

		while(1) {;}

	}
}


/*
 * 测试样例二
 * 测试对齐2 ^ {i} 的函数request2size函数是否正确
 */
extern size_t request2size(size_t req);
void test2() {

	for(int i = 0; i < 100; ++i) {
		size_t req = rand() % 128, size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if((req & size) || !(req & (size >> 1))) check(2, false, "test the request2size(size_t req)");
	}
	for(int i = 0; i < 100; ++i) {
		size_t req = 128 + (rand() % 4096), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if((req & size) || !(req & (size >> 1))) check(2, false, "test the request2size(size_t req)");
	}
	for(int i = 0; i < 100; ++i) {
		size_t req = rand(), size = request2size(req);
		printf("%#016x %#016x\n", req, size);
		if((req & size) || !(req & (size >> 1))) check(2, false, "test the request2size(size_t req)");
	}
	check(2, true, "test the request2size(size_t req)");
}

int main() {
	os->init();

	lock_init(&lock_numberOfFinished);
	/*
	 * 这里通过-DIDX=，传递宏参数
	 */
	switch(IDX) {
		case 0:
			mpe_init(test0);
			break;
		case 1:
			lock_init(&lock_test1_sum);
			mpe_init(test1);
		case 2:
			test2();
		default:
			break;
	}

	return 0;
}
#endif
