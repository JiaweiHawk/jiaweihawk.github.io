#ifndef __COMMON_H
#define __COMMON_H


#include <kernel.h>
#include <klib.h>
#include <klib-macros.h>

/*
 * 实现操作系统的锁结构，从而实现互斥
 * 这里并不是自旋锁(但可以通过简单包装，即不停循环即可)
 * 其仅仅可以上锁和开锁。如果上锁失败，则不会重新进行尝试
 */
typedef int lock_t;
bool lock(lock_t *lk);		//上锁，如果上锁失败，不会循环尝试
void unlock(lock_t *lk);		//释放锁
void lock_init(lock_t *lk);		//初始化锁


#endif
