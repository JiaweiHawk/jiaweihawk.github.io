#!/bin/sh
set -xe

# 根文件系统路径
ROOT=$(pwd)/rootfs

# 文件系统映像路径
ROOTFS=$(pwd)/rootfs.cpio

# 内核镜像路径
KERNEL=$(pwd)/linux/arch/x86_64/boot/bzImage

# exp源代码路径
EXP=$(pwd)/exp.c

# 静态编译exp
gcc -Wall -o $(pwd)/rootfs/exp -static ${EXP}

make -C driver
cp driver/vuln.ko ${ROOT}
# 生成文件系统映像
(cd ${ROOT}; find . | cpio -o --format=newc > ${ROOTFS})

# 启动qemu
qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -monitor /dev/null \
    -kernel ${KERNEL} \
    -append 'console=ttyS0 loglevel=3 oops=panic panic=1 nokaslr' \
    -initrd ${ROOTFS} \
    -no-shutdown -no-reboot \
    -s
