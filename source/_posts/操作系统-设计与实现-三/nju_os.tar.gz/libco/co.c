#include "co.h"
#include <stdlib.h>
#include <assert.h>
#include <setjmp.h>

enum co_status {
  CO_NEW = 1, // 新创建，还未执行过
  CO_RUNNING, // 已经执行过
  CO_WAITING, // 在 co_wait 上等待
  CO_DEAD,    // 已经结束，但还未释放资源
};

#define K 1024
#define STACK_SIZE (64 * K)

struct co {
  const char *name;
  void (*func)(void *); // co_start 指定的入口地址和参数
  void *arg;

  enum co_status status;		// 协程的状态
  struct co *    waiter;		// 是否有其他协程在等待当前协程
  jmp_buf        context;		// 寄存器现场 (setjmp.h)
  unsigned char stack[STACK_SIZE]; 	// 协程的堆栈
};



struct co *co_start(const char *name, void (*func)(void *), void *arg) {
	struct co *coroutine = (struct co*)malloc(sizeof(struct co));
	assert(coroutine);

	coroutine->name = name;
	coroutine->func = func;
	coroutine->arg = arg;
	coroutine->status = CO_NEW;
	coroutine->waiter = NULL;

	return coroutine;
}


typedef struct CONODE {
	struct co *coroutine;

	struct CONODE *fd, *bk;
} CoNode;


static CoNode *co_node = NULL;
/*
 * 如果co_node == NULL，则创建一个新的双向循环链表即可，并返回
 * 如果co_node != NULL, 则在co_node和co_node->fd之间插入，仍然返回co_node的值
 */
static void co_node_insert(struct co *coroutine) {
	CoNode *victim = (CoNode*)malloc(sizeof(CoNode));
	assert(victim);


	victim->coroutine = coroutine;
	if(co_node == NULL) {
		victim->fd = victim->bk = victim;
		co_node = victim;
	}else {
		victim->fd = co_node->fd;
		victim->bk = co_node;
		victim->fd->bk = victim->bk->fd = victim;
	}
}


/*
 * 如果当前只剩node一个，则返回该一个，并释放掉node即可
 * 否则，拉取当前co_node对应的协程，并沿着bk方向移动
 */
static struct co *co_node_get() {
	CoNode *victim = NULL;
	struct co *coroutine = NULL;
	if(co_node->bk == co_node) {
		coroutine = co_node->coroutine;
		free(co_node);
		co_node = NULL;
	}else if(co_node) {
		victim = co_node;
		co_node = co_node->bk;

		co_node->fd = victim->fd;
		co_node->fd->bk = co_node;

		coroutine = victim->coroutine;
		free(victim);
	}

	return coroutine;
}






void co_wait(struct co *coroutine) {
}

void co_yield() {
}
