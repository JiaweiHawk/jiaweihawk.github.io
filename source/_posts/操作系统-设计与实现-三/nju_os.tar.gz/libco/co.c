#include "co.h"
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <setjmp.h>

enum co_status {
  CO_NEW = 1, // 新创建，还未执行过
  CO_RUNNING, // 已经执行过
  CO_WAITING, // 在 co_wait 上等待
  CO_DEAD,    // 已经结束，但还未释放资源
};

#define K 1024
#define STACK_SIZE (64 * K)

struct co {
  const char *name;
  void (*func)(void *); // co_start 指定的入口地址和参数
  void *arg;

  enum co_status status;		// 协程的状态
  struct co *    waiter;		// 是否有其他协程在等待当前协程
  jmp_buf        context;		// 寄存器现场 (setjmp.h)
  unsigned char stack[STACK_SIZE]; 	// 协程的堆栈
};


struct co *current = NULL;


typedef struct CONODE {
	struct co *coroutine;

	struct CONODE *fd, *bk;
} CoNode;


static CoNode *co_node = NULL;
/*
 * 如果co_node == NULL，则创建一个新的双向循环链表即可，并返回
 * 如果co_node != NULL, 则在co_node和co_node->fd之间插入，仍然返回co_node的值
 */
static void co_node_insert(struct co *coroutine) {
	CoNode *victim = (CoNode*)malloc(sizeof(CoNode));
	assert(victim);

	victim->coroutine = coroutine;
	if(co_node == NULL) {
		victim->fd = victim->bk = victim;
		co_node = victim;
	}else {
		victim->fd = co_node->fd;
		victim->bk = co_node;
		victim->fd->bk = victim->bk->fd = victim;
	}
}


/*
 * 如果当前只剩node一个，则返回该一个
 * 否则，拉取当前co_node对应的协程，并沿着bk方向移动
 */
static CoNode *co_node_remove() {
	CoNode *victim = NULL;

	if(co_node == NULL) { return NULL; }
	else if(co_node->bk == co_node) {
		victim = co_node;
		co_node = NULL;
	}else {
		victim = co_node;

		co_node = co_node->bk;
		co_node->fd = victim->fd;
		co_node->fd->bk = co_node;
	}

	return victim;
}



struct co *co_start(const char *name, void (*func)(void *), void *arg) {
	struct co *coroutine = (struct co*)malloc(sizeof(struct co));
	assert(coroutine);

	coroutine->name = name;
	coroutine->func = func;
	coroutine->arg = arg;
	coroutine->status = CO_NEW;
	coroutine->waiter = NULL;

	co_node_insert(coroutine);
	return coroutine;
}



void co_wait(struct co *coroutine) {
	assert(coroutine);

	if(coroutine->status != CO_DEAD) {
		coroutine->waiter = current;
		current->status = CO_WAITING;
		co_yield();
	}



	/*
	 * 释放coroutine对应的CoNode
	 */
	while(co_node->coroutine != coroutine) { co_node = co_node->bk; }

	assert(co_node->coroutine == coroutine);

	free(coroutine);
	free(co_node_remove());
}



static inline void stack_switch_call(void *sp, void *entry, void* arg) {
	asm volatile (
#if __x86_64__
			"movq %0, %%rsp; movq %2, %%rdi; call *%1"
			: : "b"((uintptr_t)sp),     "d"((uintptr_t)entry), "a"((uintptr_t)arg) : "%rdi"
#else
			"movl %0, %%esp; movl %2, 0(%0); call *%1"
			: : "b"((uintptr_t)sp - 8), "d"((uintptr_t)entry), "a"((uintptr_t)arg) : "memory"
#endif
			);
}
#define __LONG_JUMP_STATUS (1)
void co_yield() {
	int status = setjmp(current->context);
	if(!status) {
		//此时开始查找待选中的进程，因为co_node应该指向的就是current对应的节点，因此首先向下移动一个，使当前线程优先级最低
		co_node = co_node->bk;
		while(!((current = co_node->coroutine)->status == CO_NEW || current->status == CO_RUNNING)) { co_node = co_node->bk; }

		assert(current);

		if(current->status == CO_RUNNING) { longjmp(current->context, __LONG_JUMP_STATUS); }
		else {
			((struct co volatile*)current)->status = CO_RUNNING;	//这里如果直接赋值，编译器会和后面的覆写进行优化

			// 栈由高地址向低地址生长
			stack_switch_call(current->stack + STACK_SIZE, current->func, current->arg);

			//此时协程已经完成执行
			current->status = CO_DEAD;

			if(current->waiter) { current->waiter->status = CO_RUNNING; }
			co_yield();
		}
	}

	assert(status && current->status == CO_RUNNING);		//此时一定是选中的进程通过longjmp跳转到的情况执行到这里
}


static __attribute__((constructor)) void co_constructor(void) {

	current = co_start("main", NULL, NULL);
	current->status = CO_RUNNING;
}


static __attribute__((destructor)) void co_destructor(void) {
	if(co_node == NULL) { return;}

	while(co_node) {
		current = co_node->coroutine;
		free(current);
		free(co_node_remove());
	}
}
