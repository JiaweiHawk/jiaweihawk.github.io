#include <stdio.h>
#include <assert.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>


/*
 * 泛型动态数组结构
 * 当number == capacity时，将其大小扩充一倍
 */
#define Array(type) (struct Array_##(#type))
#define Array_Def<type> \
	Array(type) {	\
		(#type) *arr;	\
		int size, capacity;	\
	};

static Array *array_init(unsigned int type_size, unsigned int capacity) {
	Array *array = (Array*)malloc(sizeof(Array));
	assert(array);


	array->type_size = type_size;
	array->number = 0;
	array->capacity = capacity;
	array->arr = (void*)malloc(type_size * capacity);
	assert(array->arr);

	return array;
}


static void array_insert(Array *array, void* val) {
	assert(array);

	if(array->number == array->capacity) {
		array->capacity *= 2;
		array->arr = realloc(array->arr, array->type_size * array->capacity);
	}

	assert(array->arr);
	array->arr[array->number++] = val;
}




Array *pids = array_init(sizeof(pid_t), 8);
const static char *procfs_dir = "/proc/";

/*
 * 如果是数字类型的子目录，则其为pid，返回pid的值
 * 如果不是，则返回-1
 */
static long dirent_to_pid(struct dirent *dirItem) {
	assert(dirItem);

	long pid = 0;

	if(dirItem->d_type == DT_DIR) {
		char *name = dirItem->d_name;
		for(int i = 0; name[i]; ++i) {
			if(name[i] > '9' || name[i] < '0') { return -1; }
			pid = pid * 10 + name[i] - '0';
		}
		return pid;
	}
	return -1;
}




/*
 * 动态插入pid
 * 如果大小不够了，调用realloc扩充一倍容量后继续插入
 */
static void insert_pid(long pid) {
	assert(pid > 0);
	array_insert(pids, (pid_t)pid);
}


static void get_pids(const char *dirName) {
	DIR *dir = opendir(dirName);
	assert(dir != NULL);

	struct dirent *dirItem = NULL;
	while((dirItem = readdir(dir)) != NULL) {
		long pid = dirent_to_pid(dirItem);
		if(pid > 0) { insert_pid(pid); }
	}
}



int main(int argc, char *argv[]) {
	get_pids(procfs_dir);

	for(int i = 0; i < pids_number; ++i) {
		printf("%d\n", ((pid_t*)pids->arr)[i]);
	}
	return 0;
}
